// === SCRIPT DU TABLEAU DE BORD KOYAKO ===

// Variables globales pour la gestion des données
let utilisateurActuel = null
let groupes = []
let membres = []
let invitations = []
let activites = []
let graphiques = {}

// Initialisation au chargement de la page
document.addEventListener('DOMContentLoaded', () => {
  console.log('🔷 Initialisation du tableau de bord Koyako...')
  
  verifierAuthentification()
  
  // Rediriger vers le bon dashboard selon le type d'utilisateur
  if (utilisateurActuel.type === 'membre') {
    window.location.href = 'dashboard-membre.html'
    return
  }
  
  // Si c'est un gérant, continuer avec ce dashboard
  initialiserTableauDeBord()
  chargerDonneesSimulees()
  initialiserGraphiques()
  configurerGestionnaireEvenements()
  
  console.log('✅ Tableau de bord gérant initialisé avec succès!')
})

// Vérifier l'authentification de l'utilisateur
function verifierAuthentification() {
  const donneesUtilisateur = localStorage.getItem('koyako_utilisateur')
  if (!donneesUtilisateur) {
    afficherNotification('Session expirée. Redirection...', 'erreur')
    setTimeout(() => {
      window.location.href = 'connexion.html'
    }, 2000)
    return
  }

  utilisateurActuel = JSON.parse(donneesUtilisateur)
  console.log('Utilisateur connecté:', utilisateurActuel)
  
  // Vérifier que c'est bien un gérant
  if (utilisateurActuel.type !== 'gerant') {
    afficherNotification('Accès non autorisé. Redirection...', 'erreur')
    setTimeout(() => {
      window.location.href = 'dashboard-membre.html'
    }, 2000)
    return
  }
}

// Initialiser le tableau de bord selon le type d'utilisateur
function initialiserTableauDeBord() {
  // Afficher le nom de l'utilisateur
  const nomUtilisateur = utilisateurActuel.prenom + ' ' + utilisateurActuel.nom || 'Utilisateur'
  document.getElementById('nom-utilisateur').textContent = nomUtilisateur

  // Afficher le rôle
  const roleUtilisateur = document.getElementById('role-utilisateur')
  if (roleUtilisateur) {
    roleUtilisateur.textContent = utilisateurActuel.type === 'gerant' ? 'Gérant' : 'Membre'
  }

  // GÉRER LE CODE DE CONFIRMATION POUR LES GÉRANTS
  if (utilisateurActuel.type === 'gerant') {
    // Récupérer le code depuis l'URL ou le localStorage
    let codeConfirmation = null;
    const params = new URLSearchParams(window.location.search);
    const isNouveauGérant = params.get('nouveau') === 'true';
    
    if (params.has('code')) {
      codeConfirmation = params.get('code');
      localStorage.setItem('code-confirmation-gérant', codeConfirmation);
    } else {
      codeConfirmation = localStorage.getItem('code-confirmation-gérant') || '';
    }
    
    // Afficher le code de confirmation
    const codeContainer = document.getElementById('code-admin-container');
    const codeAffiche = document.getElementById('code-admin-affiche');
    
    if (codeContainer && codeAffiche) {
      codeAffiche.textContent = codeConfirmation;
      codeContainer.style.display = 'block';
      
      // Si c'est un nouveau gérant, afficher un message de bienvenue
      if (isNouveauGérant) {
        afficherBienvenueNouveauGerant(codeConfirmation);
      }
    }
  }
}

// Afficher un message de bienvenue pour les nouveaux gérants
function afficherBienvenueNouveauGerant(codeConfirmation) {
  // Créer une notification de bienvenue
  const notification = document.createElement('div');
  notification.className = 'welcome-notification';
  notification.innerHTML = `
    <div class="welcome-content">
      <div class="welcome-header">
        <h3>🎉 Bienvenue dans votre espace gérant !</h3>
        <button class="close-welcome" onclick="this.parentElement.parentElement.parentElement.remove()">×</button>
      </div>
      <div class="welcome-body">
        <p>Votre code de confirmation : <strong>${codeConfirmation}</strong></p>
        <p>Vous pouvez maintenant :</p>
        <ul>
          <li>✅ Créer vos premiers groupes</li>
          <li>✅ Inviter des membres</li>
          <li>✅ Gérer vos tontines</li>
          <li>✅ Suivre les cotisations</li>
        </ul>
        <div class="welcome-actions">
          <button class="btn-primary" onclick="afficherSection('creer-groupe'); this.parentElement.parentElement.parentElement.remove()">
            ➕ Créer mon premier groupe
          </button>
          <button class="btn-secondary" onclick="this.parentElement.parentElement.parentElement.remove()">
            Explorer le dashboard
          </button>
        </div>
      </div>
    </div>
  `;
  
  // Styles pour la notification de bienvenue
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    max-width: 400px;
    background: white;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    z-index: 10000;
    animation: slideInRight 0.5s ease;
  `;
  
  document.body.appendChild(notification);
  
  // Supprimer automatiquement après 30 secondes
  setTimeout(() => {
    if (notification.parentElement) {
      notification.remove();
    }
  }, 30000);
}

// Générer un code administrateur unique
function genererCodeAdmin() {
  const prefixe = 'KY-ADM'
  const annee = new Date().getFullYear()
  const aleatoire = Math.floor(Math.random() * 1000).toString().padStart(3, '0')
  return `${prefixe}-${annee}-${aleatoire}`
}

// Charger des données simulées pour la démonstration
function chargerDonneesSimulees() {
  // Données simulées des groupes
  groupes = [
    {
      id: 1,
      nom: 'Famille Kinshasa',
      type: 'mensuelle',
      membres: 15,
      montant: 50000,
      statut: 'actif',
      dateCreation: '2024-01-15',
      description: 'Tontine familiale mensuelle pour les projets communs',
      adminId: utilisateurActuel.type === 'gerant' ? 'gerant' : 'autre'
    },
    {
      id: 2,
      nom: 'Amis du Bureau',
      type: 'hebdomadaire',
      membres: 8,
      montant: 25000,
      statut: 'actif',
      dateCreation: '2024-02-01',
      description: 'Tontine hebdomadaire entre collègues de travail',
      adminId: utilisateurActuel.type === 'gerant' ? 'gerant' : 'autre'
    },
    {
      id: 3,
      nom: 'Groupe Église',
      type: 'mensuelle',
      membres: 12,
      montant: 75000,
      statut: 'en-attente',
      dateCreation: '2024-02-15',
      description: 'Tontine de la communauté religieuse',
      adminId: 'autre'
    },
    {
      id: 4,
      nom: 'Voisins Quartier',
      type: 'mensuelle',
      membres: 10,
      montant: 40000,
      statut: 'actif',
      dateCreation: '2024-01-20',
      description: 'Tontine des voisins pour l\'entraide',
      adminId: utilisateurActuel.type === 'gerant' ? 'gerant' : 'autre'
    },
    {
      id: 5,
      nom: 'Anciens Étudiants',
      type: 'trimestrielle',
      membres: 20,
      montant: 100000,
      statut: 'actif',
      dateCreation: '2024-01-10',
      description: 'Tontine des anciens étudiants de l\'université',
      adminId: 'autre'
    }
  ]

  // Filtrer les groupes selon le type d'utilisateur
  if (utilisateurActuel.type !== 'gerant') {
    groupes = groupes.filter(groupe => groupe.adminId !== 'gerant')
  }

  // Données simulées des membres
  membres = [
    {
      id: 1,
      nom: 'Marie Kabila',
      email: 'marie.kabila@email.com',
      telephone: '+243 123 456 789',
      groupe: 'Famille Kinshasa',
      statut: 'actif',
      cotisations: 100,
      dateAdhesion: '2024-01-15'
    },
    {
      id: 2,
      nom: 'Jean Mukendi',
      email: 'jean.mukendi@email.com',
      telephone: '+243 987 654 321',
      groupe: 'Amis du Bureau',
      statut: 'actif',
      cotisations: 95,
      dateAdhesion: '2024-02-01'
    },
    {
      id: 3,
      nom: 'Grace Mbuyi',
      email: 'grace.mbuyi@email.com',
      telephone: '+243 555 123 456',
      groupe: 'Groupe Église',
      statut: 'en-attente',
      cotisations: 0,
      dateAdhesion: '2024-02-15'
    },
    {
      id: 4,
      nom: 'Paul Tshisekedi',
      email: 'paul.tshisekedi@email.com',
      telephone: '+243 777 888 999',
      groupe: 'Voisins Quartier',
      statut: 'actif',
      cotisations: 88,
      dateAdhesion: '2024-01-20'
    },
    {
      id: 5,
      nom: 'David Kasongo',
      email: 'david.kasongo@email.com',
      telephone: '+243 111 222 333',
      groupe: 'Anciens Étudiants',
      statut: 'actif',
      cotisations: 92,
      dateAdhesion: '2024-01-10'
    }
  ]

  // Données simulées des activités récentes
  activites = [
    {
      id: 1,
      type: 'nouveau-membre',
      message: 'Grace Mbuyi a rejoint le groupe Église',
      temps: 'Il y a 2 heures',
      icone: '👤'
    },
    {
      id: 2,
      type: 'cotisation',
      message: 'Marie Kabila a effectué sa cotisation (50,000 FC)',
      temps: 'Il y a 4 heures',
      icone: '💰'
    },
    {
      id: 3,
      type: 'nouveau-groupe',
      message: 'Nouveau groupe créé: Anciens Étudiants',
      temps: 'Il y a 1 jour',
      icone: '👥'
    },
    {
      id: 4,
      type: 'tirage',
      message: 'Tirage effectué pour le groupe Famille Kinshasa',
      temps: 'Il y a 2 jours',
      icone: '🎯'
    }
  ]

  // Mettre à jour l'affichage
  mettreAJourStatistiques()
  chargerGroupes()
  chargerMembres()
  chargerActivitesRecentes()
  remplirFiltresGroupes()
}

// Mettre à jour les statistiques du tableau de bord
function mettreAJourStatistiques() {
  document.getElementById('total-groupes').textContent = groupes.length
  document.getElementById('total-membres').textContent = membres.length

  const montantTotal = groupes.reduce((somme, groupe) => somme + (groupe.montant * groupe.membres), 0)
  document.getElementById('total-montant').textContent = montantTotal.toLocaleString()

  const membresActifs = membres.filter(m => m.statut === 'actif').length
  const tauxReussite = membres.length > 0 ? Math.round((membresActifs / membres.length) * 100) : 0
  document.getElementById('taux-reussite').textContent = tauxReussite + '%'
}

// Charger et afficher la liste des groupes
function chargerGroupes() {
  const listeGroupes = document.getElementById('liste-groupes')
  if (!listeGroupes) return

  listeGroupes.innerHTML = ''

  groupes.forEach(groupe => {
    const carteGroupe = document.createElement('div')
    carteGroupe.className = 'group-card'
    carteGroupe.innerHTML = `
      <div class="group-header">
        <h3>${groupe.nom}</h3>
        <span class="group-status ${groupe.statut}">${groupe.statut}</span>
      </div>
      <div class="group-info">
        <p class="group-description">${groupe.description}</p>
        <div class="group-stats">
          <div class="stat">
            <span class="stat-label">Membres:</span>
            <span class="stat-value">${groupe.membres}</span>
          </div>
          <div class="stat">
            <span class="stat-label">Montant:</span>
            <span class="stat-value">${groupe.montant.toLocaleString()} FC</span>
          </div>
          <div class="stat">
            <span class="stat-label">Type:</span>
            <span class="stat-value">${groupe.type}</span>
          </div>
        </div>
      </div>
      <div class="group-actions">
        <button class="btn-secondary" onclick="voirDetailsGroupe(${groupe.id})">Voir détails</button>
        ${utilisateurActuel.type === 'gerant' ? `<button class="btn-primary" onclick="gererGroupe(${groupe.id})">Gérer</button>` : ''}
      </div>
    `
    listeGroupes.appendChild(carteGroupe)
  })
}

// Charger et afficher la liste des membres
function chargerMembres() {
  const listeMembres = document.getElementById('liste-membres')
  if (!listeMembres) return

  listeMembres.innerHTML = ''

  membres.forEach(membre => {
    const carteMembre = document.createElement('div')
    carteMembre.className = 'member-card'
    carteMembre.innerHTML = `
      <div class="member-info">
        <h4>${membre.nom}</h4>
        <p>${membre.email}</p>
        <p>${membre.telephone}</p>
        <span class="member-group">${membre.groupe}</span>
      </div>
      <div class="member-stats">
        <div class="stat">
          <span class="stat-label">Cotisations:</span>
          <span class="stat-value">${membre.cotisations}%</span>
        </div>
        <div class="stat">
          <span class="stat-label">Statut:</span>
          <span class="stat-value ${membre.statut}">${membre.statut}</span>
        </div>
      </div>
    `
    listeMembres.appendChild(carteMembre)
  })
}

// Charger les activités récentes
function chargerActivitesRecentes() {
  const listeActivites = document.getElementById('liste-activites')
  if (!listeActivites) return

  listeActivites.innerHTML = ''

  activites.forEach(activite => {
    const activiteElement = document.createElement('div')
    activiteElement.className = 'activity-item'
    activiteElement.innerHTML = `
      <div class="activity-icon">${activite.icone}</div>
      <div class="activity-content">
        <p>${activite.message}</p>
        <span class="activity-time">${activite.temps}</span>
      </div>
    `
    listeActivites.appendChild(activiteElement)
  })
}

// Remplir les filtres de groupes
function remplirFiltresGroupes() {
  const filtreStatut = document.getElementById('filtre-statut')
  if (filtreStatut) {
    filtreStatut.addEventListener('change', filtrerGroupes)
  }

  const rechercheGroupe = document.getElementById('recherche-groupe')
  if (rechercheGroupe) {
    rechercheGroupe.addEventListener('input', filtrerGroupes)
  }
}

// Filtrer les groupes
function filtrerGroupes() {
  const statutFiltre = document.getElementById('filtre-statut').value
  const recherche = document.getElementById('recherche-groupe').value.toLowerCase()

  const groupesFiltres = groupes.filter(groupe => {
    const matchStatut = !statutFiltre || groupe.statut === statutFiltre
    const matchRecherche = !recherche || groupe.nom.toLowerCase().includes(recherche)
    return matchStatut && matchRecherche
  })

  afficherGroupesFiltres(groupesFiltres)
}

// Afficher les groupes filtrés
function afficherGroupesFiltres(groupesFiltres) {
  const listeGroupes = document.getElementById('liste-groupes')
  if (!listeGroupes) return

  listeGroupes.innerHTML = ''

  if (groupesFiltres.length === 0) {
    listeGroupes.innerHTML = '<div class="no-results">Aucun groupe trouvé</div>'
    return
  }

  groupesFiltres.forEach(groupe => {
    const carteGroupe = document.createElement('div')
    carteGroupe.className = 'group-card'
    carteGroupe.innerHTML = `
      <div class="group-header">
        <h3>${groupe.nom}</h3>
        <span class="group-status ${groupe.statut}">${groupe.statut}</span>
      </div>
      <div class="group-info">
        <p class="group-description">${groupe.description}</p>
        <div class="group-stats">
          <div class="stat">
            <span class="stat-label">Membres:</span>
            <span class="stat-value">${groupe.membres}</span>
          </div>
          <div class="stat">
            <span class="stat-label">Montant:</span>
            <span class="stat-value">${groupe.montant.toLocaleString()} FC</span>
          </div>
          <div class="stat">
            <span class="stat-label">Type:</span>
            <span class="stat-value">${groupe.type}</span>
          </div>
        </div>
      </div>
      <div class="group-actions">
        <button class="btn-secondary" onclick="voirDetailsGroupe(${groupe.id})">Voir détails</button>
        ${utilisateurActuel.type === 'gerant' ? `<button class="btn-primary" onclick="gererGroupe(${groupe.id})">Gérer</button>` : ''}
      </div>
    `
    listeGroupes.appendChild(carteGroupe)
  })
}

// Initialiser les graphiques
function initialiserGraphiques() {
  // Graphique des cotisations
  const ctxCotisations = document.getElementById('graphique-cotisations')
  if (ctxCotisations) {
    graphiques.cotisations = new Chart(ctxCotisations, {
      type: 'line',
      data: {
        labels: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun'],
        datasets: [{
          label: 'Cotisations (FC)',
          data: [120000, 180000, 150000, 200000, 175000, 220000],
          borderColor: '#4F46E5',
          backgroundColor: 'rgba(79, 70, 229, 0.1)',
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
          }
        }
      }
    })
  }

  // Graphique des groupes
  const ctxGroupes = document.getElementById('graphique-groupes')
  if (ctxGroupes) {
    graphiques.groupes = new Chart(ctxGroupes, {
      type: 'doughnut',
      data: {
        labels: ['Famille Kinshasa', 'Amis du Bureau', 'Groupe Église'],
        datasets: [{
          data: [15, 8, 12],
          backgroundColor: [
            '#4F46E5',
            '#10B981',
            '#F59E0B'
          ]
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom',
          }
        }
      }
    })
  }
}

// Configurer les gestionnaires d'événements
function configurerGestionnaireEvenements() {
  // Gestionnaire pour les sections
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault()
      const section = e.target.getAttribute('onclick').match(/'([^']+)'/)[1]
      afficherSection(section)
    })
  })

  // Gestionnaire pour le formulaire de paramètres
  const formParametres = document.getElementById('formulaire-parametres')
  if (formParametres) {
    formParametres.addEventListener('submit', sauvegarderParametres)
  }
}

// Afficher une section spécifique
function afficherSection(sectionId) {
  // Masquer toutes les sections
  document.querySelectorAll('.dashboard-section').forEach(section => {
    section.classList.remove('active')
  })

  // Désactiver tous les liens de navigation
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.remove('active')
  })

  // Afficher la section demandée
  const section = document.getElementById(`section-${sectionId}`)
  if (section) {
    section.classList.add('active')
  }

  // Activer le lien correspondant
  const navItem = document.querySelector(`[onclick*="${sectionId}"]`)
  if (navItem) {
    navItem.classList.add('active')
  }

  // Mettre à jour le titre
  const titrePage = document.getElementById('titre-page')
  if (titrePage) {
    const titres = {
      'vue-ensemble': 'Vue d\'ensemble',
      'mes-groupes': 'Mes Groupes',
      'gestion-membres': 'Gestion des Membres',
      'creer-groupe': 'Créer un Groupe',
      'rotation-postes': 'Rotation des Postes',
      'invitations': 'Invitations',
      'analyses': 'Analyses',
      'parametres': 'Paramètres'
    }
    titrePage.textContent = titres[sectionId] || 'Tableau de Bord'
  }
}

// Fonctions pour les actions des groupes
function voirDetailsGroupe(groupeId) {
  const groupe = groupes.find(g => g.id === groupeId)
  if (groupe) {
    afficherNotification(`Détails du groupe: ${groupe.nom}`, 'info')
    // Ici on pourrait ouvrir une modal avec les détails
  }
}

function gererGroupe(groupeId) {
  const groupe = groupes.find(g => g.id === groupeId)
  if (groupe) {
    afficherNotification(`Gestion du groupe: ${groupe.nom}`, 'info')
    // Ici on pourrait rediriger vers une page de gestion
  }
}

// Effectuer une rotation
function effectuerRotation() {
  afficherNotification('Rotation effectuée avec succès!', 'succes')
  // Logique de rotation à implémenter
}

// Sauvegarder les paramètres
function sauvegarderParametres(e) {
  e.preventDefault()
  afficherNotification('Paramètres sauvegardés!', 'succes')
  // Logique de sauvegarde à implémenter
}

// Se déconnecter
function seDeconnecter() {
  localStorage.removeItem('koyako_utilisateur')
  localStorage.removeItem('code-admin')
  window.location.href = 'connexion.html'
}

// Afficher une notification
function afficherNotification(message, type = 'info') {
  // Créer l'élément de notification
  const notification = document.createElement('div')
  notification.className = `notification ${type}`
  notification.innerHTML = `
    <div class="notification-content">
      <span class="notification-message">${message}</span>
      <button class="notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
    </div>
  `

  // Ajouter au DOM
  document.body.appendChild(notification)

  // Supprimer automatiquement après 5 secondes
  setTimeout(() => {
    if (notification.parentElement) {
      notification.remove()
    }
  }, 5000)
}

// Fonctions pour les gérants
function creerGroupe() {
  // Logique de création de groupe
  afficherNotification('Fonctionnalité de création de groupe à implémenter', 'info')
}

function genererCodeInvitation(groupeId) {
  const prefixe = 'KY-INV'
  const annee = new Date().getFullYear()
  const aleatoire = Math.floor(Math.random() * 1000).toString().padStart(3, '0')
  const code = `${prefixe}-${annee}-${aleatoire}`
  
  afficherNotification(`Code d'invitation généré: ${code}`, 'succes')
  return code
}

// Export des fonctions pour utilisation globale
window.afficherSection = afficherSection
window.voirDetailsGroupe = voirDetailsGroupe
window.gererGroupe = gererGroupe
window.effectuerRotation = effectuerRotation
window.seDeconnecter = seDeconnecter
window.creerGroupe = creerGroupe
window.genererCodeInvitation = genererCodeInvitation
