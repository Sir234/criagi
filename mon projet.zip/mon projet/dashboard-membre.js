// === SCRIPT DU TABLEAU DE BORD MEMBRE KOYAKO ===

// Variables globales pour la gestion des données
let utilisateurActuel = null
let groupesMembre = []
let cotisations = []
let notifications = []
let evenements = []
let graphiques = {}

// Initialisation au chargement de la page
document.addEventListener('DOMContentLoaded', () => {
  console.log('🔷 Initialisation du tableau de bord membre Koyako...')
  
  verifierAuthentification()
  initialiserTableauDeBordMembre()
  chargerDonneesSimuleesMembre()
  initialiserGraphiquesMembre()
  configurerGestionnaireEvenementsMembre()
  
  console.log('✅ Tableau de bord membre initialisé avec succès!')
})

// Vérifier l'authentification de l'utilisateur
function verifierAuthentification() {
  const donneesUtilisateur = localStorage.getItem('koyako_utilisateur')
  if (!donneesUtilisateur) {
    afficherNotification('Session expirée. Redirection...', 'erreur')
    setTimeout(() => {
      window.location.href = 'connexion.html'
    }, 2000)
    return
  }

  utilisateurActuel = JSON.parse(donneesUtilisateur)
  console.log('Utilisateur connecté:', utilisateurActuel)
  
  // Vérifier que c'est bien un membre
  if (utilisateurActuel.type !== 'membre') {
    afficherNotification('Accès non autorisé. Redirection...', 'erreur')
    setTimeout(() => {
      window.location.href = 'dashboard-gerant.html'
    }, 2000)
    return
  }
}

// Initialiser le tableau de bord membre
function initialiserTableauDeBordMembre() {
  // Afficher le nom de l'utilisateur
  const nomUtilisateur = utilisateurActuel.prenom + ' ' + utilisateurActuel.nom || 'Utilisateur'
  document.getElementById('nom-utilisateur').textContent = nomUtilisateur

  // Afficher le rôle
  const roleUtilisateur = document.getElementById('role-utilisateur')
  if (roleUtilisateur) {
    roleUtilisateur.textContent = 'Membre'
  }
}

// Charger des données simulées pour la démonstration
function chargerDonneesSimuleesMembre() {
  // Données simulées des groupes du membre
  groupesMembre = [
    {
      id: 1,
      nom: 'Famille Kinshasa',
      type: 'mensuelle',
      membres: 15,
      montant: 50000,
      statut: 'actif',
      dateAdhesion: '2024-01-15',
      description: 'Tontine familiale mensuelle pour les projets communs',
      positionRotation: 5,
      prochaineRotation: '2024-05-15'
    },
    {
      id: 2,
      nom: 'Amis du Bureau',
      type: 'hebdomadaire',
      membres: 8,
      montant: 25000,
      statut: 'actif',
      dateAdhesion: '2024-02-01',
      description: 'Tontine hebdomadaire entre collègues de travail',
      positionRotation: 3,
      prochaineRotation: '2024-04-08'
    },
    {
      id: 3,
      nom: 'Voisins Quartier',
      type: 'mensuelle',
      membres: 10,
      montant: 40000,
      statut: 'actif',
      dateAdhesion: '2024-01-20',
      description: 'Tontine des voisins pour l\'entraide',
      positionRotation: 7,
      prochaineRotation: '2024-06-20'
    }
  ]

  // Données simulées des cotisations
  cotisations = [
    {
      id: 1,
      groupe: 'Famille Kinshasa',
      montant: 50000,
      date: '2024-03-15',
      methode: 'mobile-money',
      statut: 'confirmee',
      commentaire: 'Cotisation mars 2024'
    },
    {
      id: 2,
      groupe: 'Amis du Bureau',
      montant: 25000,
      date: '2024-03-08',
      methode: 'especes',
      statut: 'confirmee',
      commentaire: 'Cotisation semaine 10'
    },
    {
      id: 3,
      groupe: 'Voisins Quartier',
      montant: 40000,
      date: '2024-03-20',
      methode: 'virement',
      statut: 'en-attente',
      commentaire: 'Cotisation mars 2024'
    },
    {
      id: 4,
      groupe: 'Famille Kinshasa',
      montant: 50000,
      date: '2024-02-15',
      methode: 'mobile-money',
      statut: 'confirmee',
      commentaire: 'Cotisation février 2024'
    }
  ]

  // Données simulées des notifications
  notifications = [
    {
      id: 1,
      type: 'cotisation',
      titre: 'Rappel de cotisation',
      message: 'Votre cotisation pour le groupe "Famille Kinshasa" est due le 15 avril',
      date: '2024-04-10',
      lu: false,
      priorite: 'haute'
    },
    {
      id: 2,
      type: 'rotation',
      titre: 'Rotation effectuée',
      message: 'La rotation a été effectuée dans le groupe "Amis du Bureau"',
      date: '2024-04-08',
      lu: true,
      priorite: 'normale'
    },
    {
      id: 3,
      type: 'groupe',
      titre: 'Nouveau membre',
      message: 'Un nouveau membre a rejoint le groupe "Voisins Quartier"',
      date: '2024-04-05',
      lu: true,
      priorite: 'basse'
    }
  ]

  // Données simulées des événements
  evenements = [
    {
      id: 1,
      type: 'cotisation',
      titre: 'Échéance cotisation',
      description: 'Famille Kinshasa - 50,000 FC',
      date: '2024-04-15',
      groupe: 'Famille Kinshasa'
    },
    {
      id: 2,
      type: 'rotation',
      titre: 'Rotation hebdomadaire',
      description: 'Amis du Bureau - Tirage au sort',
      date: '2024-04-08',
      groupe: 'Amis du Bureau'
    },
    {
      id: 3,
      type: 'reunion',
      titre: 'Réunion mensuelle',
      description: 'Voisins Quartier - Discussion projets',
      date: '2024-04-25',
      groupe: 'Voisins Quartier'
    }
  ]

  // Mettre à jour l'affichage
  mettreAJourStatistiquesMembre()
  chargerGroupesMembre()
  chargerCotisations()
  chargerNotifications()
  chargerEvenements()
  remplirFiltresMembre()
}

// Mettre à jour les statistiques du tableau de bord membre
function mettreAJourStatistiquesMembre() {
  document.getElementById('total-groupes-membre').textContent = groupesMembre.length

  const totalCotise = cotisations
    .filter(c => c.statut === 'confirmee')
    .reduce((somme, cotisation) => somme + cotisation.montant, 0)
  document.getElementById('total-cotise').textContent = totalCotise.toLocaleString()

  const cotisationsConfirmees = cotisations.filter(c => c.statut === 'confirmee').length
  const totalCotisations = cotisations.length
  const tauxParticipation = totalCotisations > 0 ? Math.round((cotisationsConfirmees / totalCotisations) * 100) : 0
  document.getElementById('taux-participation').textContent = tauxParticipation + '%'

  // Calculer la position moyenne dans la rotation
  const positions = groupesMembre.map(g => g.positionRotation)
  const positionMoyenne = positions.length > 0 ? Math.round(positions.reduce((a, b) => a + b, 0) / positions.length) : 0
  document.getElementById('position-rotation').textContent = positionMoyenne + 'ème'
}

// Charger et afficher la liste des groupes du membre
function chargerGroupesMembre() {
  const listeGroupes = document.getElementById('liste-groupes-membre')
  if (!listeGroupes) return

  listeGroupes.innerHTML = ''

  groupesMembre.forEach(groupe => {
    const carteGroupe = document.createElement('div')
    carteGroupe.className = 'group-card'
    carteGroupe.innerHTML = `
      <div class="group-header">
        <h3>${groupe.nom}</h3>
        <span class="group-status ${groupe.statut}">${groupe.statut}</span>
      </div>
      <div class="group-info">
        <p class="group-description">${groupe.description}</p>
        <div class="group-stats">
          <div class="stat">
            <span class="stat-label">Membres:</span>
            <span class="stat-value">${groupe.membres}</span>
          </div>
          <div class="stat">
            <span class="stat-label">Montant:</span>
            <span class="stat-value">${groupe.montant.toLocaleString()} FC</span>
          </div>
          <div class="stat">
            <span class="stat-label">Type:</span>
            <span class="stat-value">${groupe.type}</span>
          </div>
          <div class="stat">
            <span class="stat-label">Position:</span>
            <span class="stat-value">${groupe.positionRotation}ème</span>
          </div>
        </div>
      </div>
      <div class="group-actions">
        <button class="btn-secondary" onclick="voirDetailsGroupeMembre(${groupe.id})">Voir détails</button>
        <button class="btn-primary" onclick="effectuerCotisation(${groupe.id})">Cotiser</button>
      </div>
    `
    listeGroupes.appendChild(carteGroupe)
  })
}

// Charger et afficher les cotisations
function chargerCotisations() {
  const historiqueCotisations = document.getElementById('historique-cotisations')
  if (!historiqueCotisations) return

  historiqueCotisations.innerHTML = ''

  cotisations.forEach(cotisation => {
    const ligne = document.createElement('tr')
    ligne.innerHTML = `
      <td>${new Date(cotisation.date).toLocaleDateString('fr-FR')}</td>
      <td>${cotisation.groupe}</td>
      <td>${cotisation.montant.toLocaleString()} FC</td>
      <td>${cotisation.methode}</td>
      <td><span class="status ${cotisation.statut}">${cotisation.statut}</span></td>
    `
    historiqueCotisations.appendChild(ligne)
  })

  // Mettre à jour les résumés
  const totalCotise = cotisations
    .filter(c => c.statut === 'confirmee')
    .reduce((somme, cotisation) => somme + cotisation.montant, 0)
  document.getElementById('total-cotise-affichage').textContent = totalCotise.toLocaleString() + ' FC'

  // Calculer la prochaine échéance
  const prochaineEcheance = new Date()
  prochaineEcheance.setDate(prochaineEcheance.getDate() + 5)
  document.getElementById('prochaine-echeance').textContent = prochaineEcheance.toLocaleDateString('fr-FR')

  // Montant à payer (simulation)
  const montantAPayer = 25000
  document.getElementById('montant-a-payer').textContent = montantAPayer.toLocaleString() + ' FC'
}

// Charger les notifications
function chargerNotifications() {
  const listeNotifications = document.getElementById('liste-notifications')
  if (!listeNotifications) return

  listeNotifications.innerHTML = ''

  notifications.forEach(notification => {
    const notificationElement = document.createElement('div')
    notificationElement.className = `notification-item ${notification.lu ? 'read' : 'unread'} ${notification.priorite}`
    notificationElement.innerHTML = `
      <div class="notification-icon">
        ${getNotificationIcon(notification.type)}
      </div>
      <div class="notification-content">
        <h4>${notification.titre}</h4>
        <p>${notification.message}</p>
        <span class="notification-date">${new Date(notification.date).toLocaleDateString('fr-FR')}</span>
      </div>
      <div class="notification-actions">
        <button class="btn-mark-read" onclick="marquerCommeLu(${notification.id})">
          ${notification.lu ? '✓' : '○'}
        </button>
      </div>
    `
    listeNotifications.appendChild(notificationElement)
  })
}

// Charger les événements
function chargerEvenements() {
  const listeEvenements = document.getElementById('liste-evenements')
  if (!listeEvenements) return

  listeEvenements.innerHTML = ''

  evenements.forEach(evenement => {
    const evenementElement = document.createElement('div')
    evenementElement.className = 'event-item'
    evenementElement.innerHTML = `
      <div class="event-icon">
        ${getEventIcon(evenement.type)}
      </div>
      <div class="event-content">
        <h4>${evenement.titre}</h4>
        <p>${evenement.description}</p>
        <span class="event-date">${new Date(evenement.date).toLocaleDateString('fr-FR')}</span>
      </div>
    `
    listeEvenements.appendChild(evenementElement)
  })
}

// Obtenir l'icône pour les notifications
function getNotificationIcon(type) {
  const icones = {
    'cotisation': '💰',
    'rotation': '🔄',
    'groupe': '👥',
    'systeme': '⚙️'
  }
  return icones[type] || '📢'
}

// Obtenir l'icône pour les événements
function getEventIcon(type) {
  const icones = {
    'cotisation': '💰',
    'rotation': '🔄',
    'reunion': '👥',
    'reminder': '⏰'
  }
  return icones[type] || '📅'
}

// Remplir les filtres
function remplirFiltresMembre() {
  const filtreStatut = document.getElementById('filtre-statut-membre')
  if (filtreStatut) {
    filtreStatut.addEventListener('change', filtrerGroupesMembre)
  }

  const rechercheGroupe = document.getElementById('recherche-groupe-membre')
  if (rechercheGroupe) {
    rechercheGroupe.addEventListener('input', filtrerGroupesMembre)
  }
}

// Filtrer les groupes
function filtrerGroupesMembre() {
  const statutFiltre = document.getElementById('filtre-statut-membre').value
  const recherche = document.getElementById('recherche-groupe-membre').value.toLowerCase()

  const groupesFiltres = groupesMembre.filter(groupe => {
    const matchStatut = !statutFiltre || groupe.statut === statutFiltre
    const matchRecherche = !recherche || groupe.nom.toLowerCase().includes(recherche)
    return matchStatut && matchRecherche
  })

  afficherGroupesFiltresMembre(groupesFiltres)
}

// Afficher les groupes filtrés
function afficherGroupesFiltresMembre(groupesFiltres) {
  const listeGroupes = document.getElementById('liste-groupes-membre')
  if (!listeGroupes) return

  listeGroupes.innerHTML = ''

  if (groupesFiltres.length === 0) {
    listeGroupes.innerHTML = '<div class="no-results">Aucun groupe trouvé</div>'
    return
  }

  groupesFiltres.forEach(groupe => {
    const carteGroupe = document.createElement('div')
    carteGroupe.className = 'group-card'
    carteGroupe.innerHTML = `
      <div class="group-header">
        <h3>${groupe.nom}</h3>
        <span class="group-status ${groupe.statut}">${groupe.statut}</span>
      </div>
      <div class="group-info">
        <p class="group-description">${groupe.description}</p>
        <div class="group-stats">
          <div class="stat">
            <span class="stat-label">Membres:</span>
            <span class="stat-value">${groupe.membres}</span>
          </div>
          <div class="stat">
            <span class="stat-label">Montant:</span>
            <span class="stat-value">${groupe.montant.toLocaleString()} FC</span>
          </div>
          <div class="stat">
            <span class="stat-label">Type:</span>
            <span class="stat-value">${groupe.type}</span>
          </div>
          <div class="stat">
            <span class="stat-label">Position:</span>
            <span class="stat-value">${groupe.positionRotation}ème</span>
          </div>
        </div>
      </div>
      <div class="group-actions">
        <button class="btn-secondary" onclick="voirDetailsGroupeMembre(${groupe.id})">Voir détails</button>
        <button class="btn-primary" onclick="effectuerCotisation(${groupe.id})">Cotiser</button>
      </div>
    `
    listeGroupes.appendChild(carteGroupe)
  })
}

// Initialiser les graphiques pour les membres
function initialiserGraphiquesMembre() {
  // Graphique des cotisations du membre
  const ctxCotisations = document.getElementById('graphique-cotisations-membre')
  if (ctxCotisations) {
    graphiques.cotisationsMembre = new Chart(ctxCotisations, {
      type: 'line',
      data: {
        labels: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun'],
        datasets: [{
          label: 'Mes Cotisations (FC)',
          data: [50000, 75000, 115000, 140000, 165000, 190000],
          borderColor: '#4F46E5',
          backgroundColor: 'rgba(79, 70, 229, 0.1)',
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'top',
          }
        }
      }
    })
  }

  // Graphique des groupes du membre
  const ctxGroupes = document.getElementById('graphique-groupes-membre')
  if (ctxGroupes) {
    graphiques.groupesMembre = new Chart(ctxGroupes, {
      type: 'doughnut',
      data: {
        labels: ['Famille Kinshasa', 'Amis du Bureau', 'Voisins Quartier'],
        datasets: [{
          data: [150000, 75000, 80000],
          backgroundColor: [
            '#4F46E5',
            '#10B981',
            '#F59E0B'
          ]
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom',
          }
        }
      }
    })
  }
}

// Configurer les gestionnaires d'événements
function configurerGestionnaireEvenementsMembre() {
  // Gestionnaire pour les sections
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', (e) => {
      e.preventDefault()
      const section = e.target.getAttribute('onclick').match(/'([^']+)'/)[1]
      afficherSection(section)
    })
  })

  // Gestionnaire pour le formulaire de cotisation
  const formCotisation = document.getElementById('formulaire-cotisation')
  if (formCotisation) {
    formCotisation.addEventListener('submit', effectuerCotisation)
  }

  // Gestionnaire pour le formulaire de paramètres
  const formParametres = document.getElementById('formulaire-parametres-membre')
  if (formParametres) {
    formParametres.addEventListener('submit', sauvegarderParametresMembre)
  }
}

// Afficher une section spécifique
function afficherSection(sectionId) {
  // Masquer toutes les sections
  document.querySelectorAll('.dashboard-section').forEach(section => {
    section.classList.remove('active')
  })

  // Désactiver tous les liens de navigation
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.remove('active')
  })

  // Afficher la section demandée
  const section = document.getElementById(`section-${sectionId}`)
  if (section) {
    section.classList.add('active')
  }

  // Activer le lien correspondant
  const navItem = document.querySelector(`[onclick*="${sectionId}"]`)
  if (navItem) {
    navItem.classList.add('active')
  }

  // Mettre à jour le titre
  const titrePage = document.getElementById('titre-page')
  if (titrePage) {
    const titres = {
      'vue-ensemble': 'Vue d\'ensemble',
      'mes-groupes': 'Mes Groupes',
      'mes-cotisations': 'Mes Cotisations',
      'rejoindre-groupe': 'Rejoindre un Groupe',
      'historique': 'Historique',
      'notifications': 'Notifications',
      'parametres': 'Paramètres'
    }
    titrePage.textContent = titres[sectionId] || 'Tableau de Bord'
  }
}

// Fonctions pour les actions des membres
function voirDetailsGroupeMembre(groupeId) {
  const groupe = groupesMembre.find(g => g.id === groupeId)
  if (groupe) {
    afficherNotification(`Détails du groupe: ${groupe.nom}`, 'info')
    // Ici on pourrait ouvrir une modal avec les détails
  }
}

function effectuerCotisation(groupeId) {
  if (typeof groupeId === 'object') {
    // C'est un événement de formulaire
    groupeId.preventDefault()
    const formData = new FormData(groupeId.target)
    const groupe = formData.get('groupe-cotisation')
    const montant = formData.get('montant-cotisation-membre')
    
    afficherNotification(`Cotisation de ${montant} FC effectuée pour le groupe ${groupe}`, 'succes')
  } else {
    // C'est un appel direct avec l'ID du groupe
    const groupe = groupesMembre.find(g => g.id === groupeId)
    if (groupe) {
      afficherNotification(`Ouverture du formulaire de cotisation pour: ${groupe.nom}`, 'info')
      afficherSection('mes-cotisations')
    }
  }
}

// Marquer une notification comme lue
function marquerCommeLu(notificationId) {
  const notification = notifications.find(n => n.id === notificationId)
  if (notification) {
    notification.lu = !notification.lu
    chargerNotifications()
    afficherNotification('Statut de notification mis à jour', 'succes')
  }
}

// Filtrer les notifications
function filtrerNotifications(type) {
  // Mettre à jour les boutons de filtre
  document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.classList.remove('active')
  })
  event.target.classList.add('active')

  // Filtrer les notifications
  const notificationsFiltrees = type === 'toutes' 
    ? notifications 
    : notifications.filter(n => n.type === type)

  afficherNotificationsFiltrees(notificationsFiltrees)
}

// Afficher les notifications filtrées
function afficherNotificationsFiltrees(notificationsFiltrees) {
  const listeNotifications = document.getElementById('liste-notifications')
  if (!listeNotifications) return

  listeNotifications.innerHTML = ''

  if (notificationsFiltrees.length === 0) {
    listeNotifications.innerHTML = '<div class="no-notifications">Aucune notification trouvée</div>'
    return
  }

  notificationsFiltrees.forEach(notification => {
    const notificationElement = document.createElement('div')
    notificationElement.className = `notification-item ${notification.lu ? 'read' : 'unread'} ${notification.priorite}`
    notificationElement.innerHTML = `
      <div class="notification-icon">
        ${getNotificationIcon(notification.type)}
      </div>
      <div class="notification-content">
        <h4>${notification.titre}</h4>
        <p>${notification.message}</p>
        <span class="notification-date">${new Date(notification.date).toLocaleDateString('fr-FR')}</span>
      </div>
      <div class="notification-actions">
        <button class="btn-mark-read" onclick="marquerCommeLu(${notification.id})">
          ${notification.lu ? '✓' : '○'}
        </button>
      </div>
    `
    listeNotifications.appendChild(notificationElement)
  })
}

// Afficher un onglet
function afficherOnglet(onglet) {
  // Masquer tous les onglets
  document.querySelectorAll('.tab-pane').forEach(pane => {
    pane.classList.remove('active')
  })

  // Désactiver tous les boutons d'onglet
  document.querySelectorAll('.tab-button').forEach(btn => {
    btn.classList.remove('active')
  })

  // Afficher l'onglet demandé
  const pane = document.getElementById(`onglet-${onglet}`)
  if (pane) {
    pane.classList.add('active')
  }

  // Activer le bouton correspondant
  const button = event.target
  if (button) {
    button.classList.add('active')
  }
}

// Sauvegarder les paramètres
function sauvegarderParametresMembre(e) {
  e.preventDefault()
  afficherNotification('Paramètres sauvegardés!', 'succes')
  // Logique de sauvegarde à implémenter
}

// Se déconnecter
function seDeconnecter() {
  localStorage.removeItem('koyako_utilisateur')
  window.location.href = 'connexion.html'
}

// Afficher une notification
function afficherNotification(message, type = 'info') {
  // Créer l'élément de notification
  const notification = document.createElement('div')
  notification.className = `notification ${type}`
  notification.innerHTML = `
    <div class="notification-content">
      <span class="notification-message">${message}</span>
      <button class="notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
    </div>
  `

  // Ajouter au DOM
  document.body.appendChild(notification)

  // Supprimer automatiquement après 5 secondes
  setTimeout(() => {
    if (notification.parentElement) {
      notification.remove()
    }
  }, 5000)
}

// Export des fonctions pour utilisation globale
window.afficherSection = afficherSection
window.voirDetailsGroupeMembre = voirDetailsGroupeMembre
window.effectuerCotisation = effectuerCotisation
window.marquerCommeLu = marquerCommeLu
window.filtrerNotifications = filtrerNotifications
window.afficherOnglet = afficherOnglet
window.seDeconnecter = seDeconnecter 