// === SCRIPT POUR LA PAGE SOLUTION ===

document.addEventListener('DOMContentLoaded', () => {
  console.log('💡 Chargement de la page solution Koyako...')
  
  initialiserNavigation()
  initialiserAnimations()
  initialiserSlider()
  initialiserInteractions()
  
  console.log('✅ Page solution chargée avec succès!')
})

// Initialiser la navigation
function initialiserNavigation() {
  const hamburger = document.querySelector('.hamburger')
  const navMenu = document.querySelector('.nav-menu')

  if (hamburger && navMenu) {
    hamburger.addEventListener('click', () => {
      hamburger.classList.toggle('active')
      navMenu.classList.toggle('active')
    })

    document.querySelectorAll('.nav-menu a').forEach(lien => {
      lien.addEventListener('click', () => {
        hamburger.classList.remove('active')
        navMenu.classList.remove('active')
      })
    })
  }

  // Effet de défilement sur la navbar
  window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar')
    if (window.scrollY > 50) {
      navbar.style.background = 'rgba(255, 255, 255, 0.98)'
      navbar.style.boxShadow = '0 2px 20px rgba(0,0,0,0.1)'
    } else {
      navbar.style.background = 'rgba(255, 255, 255, 0.95)'
      navbar.style.boxShadow = 'none'
    }
  })
}

// Initialiser les animations
function initialiserAnimations() {
  // Observer pour les éléments à animer
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1'
        entry.target.style.transform = 'translateY(0)'
      }
    })
  }, { threshold: 0.1 })

  // Animer les cartes de problèmes
  document.querySelectorAll('.probleme-item').forEach((item, index) => {
    item.style.opacity = '0'
    item.style.transform = 'translateY(30px)'
    item.style.transition = `all 0.6s ease ${index * 0.1}s`
    observer.observe(item)
  })

  // Animer les piliers d'approche
  document.querySelectorAll('.pillar-item').forEach((item, index) => {
    item.style.opacity = '0'
    item.style.transform = 'translateX(-30px)'
    item.style.transition = `all 0.6s ease ${index * 0.2}s`
    observer.observe(item)
  })

  // Animer les cartes de solution
  document.querySelectorAll('.solution-card').forEach((card, index) => {
    card.style.opacity = '0'
    card.style.transform = 'translateY(50px)'
    card.style.transition = `all 0.8s ease ${index * 0.1}s`
    observer.observe(card)
  })

  // Animer les statistiques d'impact
  document.querySelectorAll('.stat-item').forEach((stat, index) => {
    stat.style.opacity = '0'
    stat.style.transform = 'scale(0.8)'
    stat.style.transition = `all 0.6s ease ${index * 0.1}s`
    observer.observe(stat)
  })
}

// Initialiser le slider de témoignages
function initialiserSlider() {
  const slides = document.querySelectorAll('.testimonial-slide')
  const dots = document.querySelectorAll('.dot')
  const prevBtn = document.querySelector('.prev-btn')
  const nextBtn = document.querySelector('.next-btn')
  
  if (slides.length === 0) return

  let currentSlide = 0

  // Afficher le premier slide
  slides[0].classList.add('active')

  // Fonction pour changer de slide
  function changerSlide(index) {
    slides[currentSlide].classList.remove('active')
    dots[currentSlide].classList.remove('active')
    
    currentSlide = index
    
    slides[currentSlide].classList.add('active')
    dots[currentSlide].classList.add('active')
  }

  // Fonction pour slide suivant
  function slideSuivant() {
    const nextIndex = (currentSlide + 1) % slides.length
    changerSlide(nextIndex)
  }

  // Fonction pour slide précédent
  function slidePrecedent() {
    const prevIndex = (currentSlide - 1 + slides.length) % slides.length
    changerSlide(prevIndex)
  }

  // Event listeners
  if (nextBtn) nextBtn.addEventListener('click', slideSuivant)
  if (prevBtn) prevBtn.addEventListener('click', slidePrecedent)

  // Event listeners pour les dots
  dots.forEach((dot, index) => {
    dot.addEventListener('click', () => changerSlide(index))
  })

  // Auto-play du slider
  setInterval(slideSuivant, 5000)
}

// Initialiser les interactions
function initialiserInteractions() {
  // Effet hover pour les cartes de problème
  document.querySelectorAll('.probleme-item').forEach(item => {
    item.addEventListener('mouseenter', () => {
      const icon = item.querySelector('.probleme-icon')
      icon.style.transform = 'scale(1.2) rotate(10deg)'
    })

    item.addEventListener('mouseleave', () => {
      const icon = item.querySelector('.probleme-icon')
      icon.style.transform = 'scale(1) rotate(0deg)'
    })
  })

  // Effet hover pour les piliers d'approche
  document.querySelectorAll('.pillar-item').forEach(item => {
    item.addEventListener('mouseenter', () => {
      const icon = item.querySelector('.pillar-icon')
      icon.style.transform = 'scale(1.2)'
      icon.style.background = '#2563eb'
      icon.style.color = 'white'
    })

    item.addEventListener('mouseleave', () => {
      const icon = item.querySelector('.pillar-icon')
      icon.style.transform = 'scale(1)'
      icon.style.background = '#dbeafe'
      icon.style.color = '#2563eb'
    })
  })

  // Animation des statistiques au survol
  document.querySelectorAll('.stat-item').forEach(stat => {
    stat.addEventListener('mouseenter', () => {
      const number = stat.querySelector('.stat-number')
      number.style.transform = 'scale(1.1)'
      number.style.color = '#1d4ed8'
    })

    stat.addEventListener('mouseleave', () => {
      const number = stat.querySelector('.stat-number')
      number.style.transform = 'scale(1)'
      number.style.color = '#2563eb'
    })
  })

  // Animation des cartes de solution
  document.querySelectorAll('.solution-card').forEach(card => {
    card.addEventListener('mouseenter', () => {
      const icon = card.querySelector('.solution-icon')
      icon.style.transform = 'scale(1.2) rotate(360deg)'
      icon.style.background = '#2563eb'
      icon.style.color = 'white'
    })

    card.addEventListener('mouseleave', () => {
      const icon = card.querySelector('.solution-icon')
      icon.style.transform = 'scale(1) rotate(0deg)'
      icon.style.background = '#dbeafe'
      icon.style.color = '#2563eb'
    })
  })
}

// Gestion du redimensionnement
window.addEventListener('resize', () => {
  const hamburger = document.querySelector('.hamburger')
  const navMenu = document.querySelector('.nav-menu')
  
  if (window.innerWidth > 768) {
    hamburger?.classList.remove('active')
    navMenu?.classList.remove('active')
  }
})

// Animation de compteur pour les statistiques
function animerCompteur(element, valeurCible, duree = 2000) {
  let valeurActuelle = 0
  const increment = valeurCible / (duree / 16)
  const texteOriginal = element.textContent
  const suffixe = texteOriginal.replace(/[\d,+-]/g, '')

  const timer = setInterval(() => {
    valeurActuelle += increment
    let valeurAffichee = Math.floor(valeurActuelle)
    
    if (texteOriginal.includes('+')) {
      element.textContent = '+' + valeurAffichee + suffixe.replace(/[+]/g, '')
    } else if (texteOriginal.includes('-')) {
      element.textContent = '-' + valeurAffichee + suffixe.replace(/[-]/g, '')
    } else {
      element.textContent = valeurAffichee + suffixe
    }

    if (valeurActuelle >= valeurCible) {
      element.textContent = texteOriginal
      clearInterval(timer)
    }
  }, 16)
}

// Démarrer l'animation des compteurs quand ils deviennent visibles
const observerCompteurs = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const number = entry.target.querySelector('.stat-number')
      const valeur = parseInt(number.textContent.replace(/[^\d]/g, ''))
      animerCompteur(number, valeur)
      observerCompteurs.unobserve(entry.target)
    }
  })
})

document.querySelectorAll('.stat-item').forEach(stat => {
  observerCompteurs.observe(stat)
})

console.log('💡 Script solution Koyako chargé!')
