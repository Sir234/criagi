// Member dashboard functionality
let currentUser = null
let memberGroups = []

document.addEventListener("DOMContentLoaded", () => {
  // Check authentication
  const userData = localStorage.getItem("koyako_utilisateur")
  if (!userData) {
    window.location.href = "index.html"
    return
  }

  currentUser = JSON.parse(userData)
  // Vérification du rôle : seul un membre peut accéder à ce dashboard
  if (currentUser.type !== "membre") {
    window.location.href = "dashboard.html"
    return
  }

  // Initialize member dashboard
  initializeMemberDashboard()
  loadMemberData()
  setupMemberFormHandlers()
})

function initializeMemberDashboard() {
  // Set member name
  document.getElementById("member-name").textContent = currentUser.name || "Membre"
}

function loadMemberData() {
  // Mock member groups data
  memberGroups = [
    {
      id: 1,
      name: "Famille Kinshasa",
      type: "monthly",
      contribution: 50000,
      nextPayment: "2024-03-15",
      totalMembers: 15,
      currentRound: 3,
      myTurn: 8,
      status: "active",
      progress: 60,
    },
    {
      id: 2,
      name: "Amis du Bureau",
      type: "weekly",
      contribution: 25000,
      nextPayment: "2024-03-01",
      totalMembers: 8,
      currentRound: 1,
      myTurn: 3,
      status: "active",
      progress: 25,
    },
    {
      id: 3,
      name: "Groupe Église",
      type: "monthly",
      contribution: 75000,
      nextPayment: "2024-03-20",
      totalMembers: 12,
      currentRound: 1,
      myTurn: 7,
      status: "pending",
      progress: 10,
    },
  ]

  loadMemberGroups()
}

function loadMemberGroups() {
  const groupsList = document.getElementById("member-groups-list")
  groupsList.innerHTML = ""

  memberGroups.forEach((group) => {
    const groupCard = document.createElement("div")
    groupCard.className = "member-group-card"
    groupCard.innerHTML = `
            <div class="group-header">
                <h3>${group.name}</h3>
                <span class="group-status status-${group.status}">
                    ${group.status === "active" ? "Actif" : "En attente"}
                </span>
            </div>
            
            <div class="group-info">
                <p><strong>Type:</strong> ${getTypeLabel(group.type)}</p>
                <p><strong>Cotisation:</strong> ${group.contribution.toLocaleString()} FC</p>
                <p><strong>Prochain paiement:</strong> ${formatDate(group.nextPayment)}</p>
                <p><strong>Mon tour:</strong> ${group.myTurn}/${group.totalMembers}</p>
            </div>
            
            <div class="group-progress">
                <div class="progress-info">
                    <span>Progression du cycle</span>
                    <span>${group.progress}%</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill" style="width: ${group.progress}%"></div>
                </div>
            </div>
            
            <div class="group-actions">
                <button class="btn-primary" onclick="viewGroupDetails(${group.id})">
                    Voir détails
                </button>
                ${
                  group.status === "active"
                    ? `<button class="btn-secondary" onclick="makePayment(${group.id})">
                        Effectuer paiement
                    </button>`
                    : ""
                }
            </div>
        `
    groupsList.appendChild(groupCard)
  })
}

function setupMemberFormHandlers() {
  // Join group form
  document.getElementById("join-group-form").addEventListener("submit", function (e) {
    e.preventDefault()

    const inviteCode = document.getElementById("invitation-code").value

    // Validate invite code format
    if (!inviteCode.startsWith("KY-INV-")) {
      alert("Code d'invitation invalide. Le format doit être: KY-INV-XXXX-XXX")
      return
    }

    // Simulate joining group
    const newGroup = {
      id: memberGroups.length + 1,
      name: "Nouveau Groupe",
      type: "monthly",
      contribution: 40000,
      nextPayment: "2024-03-25",
      totalMembers: 10,
      currentRound: 1,
      myTurn: 10,
      status: "pending",
      progress: 0,
    }

    memberGroups.push(newGroup)

    alert(
      `Demande d'adhésion envoyée avec succès!\nVous recevrez une confirmation une fois approuvé par l'administrateur.`,
    )

    // Reset form and update display
    this.reset()
    loadMemberGroups()
    showMemberSection("my-groups")
  })
}

// Navigation functions for member dashboard
function showMemberSection(sectionName) {
  // Hide all sections
  document.querySelectorAll(".dashboard-section").forEach((section) => {
    section.classList.remove("active")
  })

  // Remove active class from all nav items
  document.querySelectorAll(".nav-item").forEach((item) => {
    item.classList.remove("active")
  })

  // Show selected section
  document.getElementById(sectionName + "-section").classList.add("active")

  // Add active class to clicked nav item
  document.querySelector(`[onclick="showMemberSection('${sectionName}')"]`).classList.add("active")

  // Update page title
  const titles = {
    "my-groups": "Mes Groupes",
    contributions: "Mes Cotisations",
    "join-group": "Rejoindre un Groupe",
    profile: "Mon Profil",
  }

  document.getElementById("member-page-title").textContent = titles[sectionName]
}

// Member-specific functions
function viewGroupDetails(groupId) {
  const group = memberGroups.find((g) => g.id === groupId)
  alert(
    `Détails du groupe: ${group.name}\n` +
      `Type: ${getTypeLabel(group.type)}\n` +
      `Cotisation: ${group.contribution.toLocaleString()} FC\n` +
      `Mon tour: ${group.myTurn}/${group.totalMembers}\n` +
      `Prochain paiement: ${formatDate(group.nextPayment)}`,
  )
}

function makePayment(groupId) {
  const group = memberGroups.find((g) => g.id === groupId)

  if (confirm(`Confirmer le paiement de ${group.contribution.toLocaleString()} FC pour ${group.name}?`)) {
    alert("Paiement effectué avec succès!\nVous recevrez une confirmation par SMS/Email.")

    // Update group progress (simulation)
    group.progress = Math.min(group.progress + 10, 100)
    loadMemberGroups()
  }
}

// Utility functions (shared with admin dashboard)
function getTypeLabel(type) {
  const labels = {
    weekly: "Hebdomadaire",
    monthly: "Mensuelle",
    quarterly: "Trimestrielle",
  }
  return labels[type] || type
}

function formatDate(dateString) {
  return new Date(dateString).toLocaleDateString("fr-FR")
}

function logout() {
  if (confirm("Êtes-vous sûr de vouloir vous déconnecter?")) {
    localStorage.removeItem("koyako_user")
    window.location.href = "index.html"
  }
}
