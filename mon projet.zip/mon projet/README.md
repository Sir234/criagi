# 🔷 Koyako - Système de Gestion de Tontines

Un système moderne et intuitif pour la gestion de tontines avec deux interfaces distinctes : une pour les gérants et une pour les membres.

## 📋 Table des Matières

- [Fonctionnalités](#-fonctionnalités)
- [Architecture](#-architecture)
- [Installation](#-installation)
- [Utilisation](#-utilisation)
- [Structure des Fichiers](#-structure-des-fichiers)
- [Comptes de Démonstration](#-comptes-de-démonstration)
- [Technologies Utilisées](#-technologies-utilisées)

## ✨ Fonctionnalités

### 🎯 Dashboard Gérant (`dashboard-gerant.html`)

**Fonctionnalités d'administration complètes :**

- **📊 Vue d'ensemble** : Statistiques globales, graphiques de performance
- **👥 Gestion des Groupes** : Création, modification, suppression de groupes
- **👤 Gestion des Membres** : Suivi des participants, gestion des cotisations
- **➕ Création de Groupes** : Interface complète de création avec paramètres avancés
- **📧 Système d'Invitations** : Invitations par email et codes d'invitation
- **🔄 Rotation des Postes** : Gestion automatique des rotations et tirages
- **📈 Analyses Avancées** : Graphiques de performance, rapports détaillés
- **⚙️ Paramètres** : Configuration du compte et notifications

**Fonctionnalités spécifiques :**
- Génération automatique de codes administrateur uniques
- Gestion des codes d'invitation pour les groupes
- Tableau de bord analytique avec métriques avancées
- Système de rotation automatique des bénéficiaires
- Gestion complète des membres et de leurs statuts

### 👤 Dashboard Membre (`dashboard-membre.html`)

**Interface adaptée aux participants :**

- **📊 Vue d'ensemble** : Statistiques personnelles, position dans les rotations
- **👥 Mes Groupes** : Visualisation des groupes rejoints
- **💰 Mes Cotisations** : Suivi des paiements, historique des cotisations
- **➕ Rejoindre un Groupe** : Interface pour rejoindre de nouveaux groupes
- **📋 Historique** : Historique complet des activités
- **🔔 Notifications** : Système de notifications personnalisées
- **⚙️ Paramètres** : Gestion du profil et préférences

**Fonctionnalités spécifiques :**
- Suivi des cotisations personnelles
- Position dans la rotation des bénéficiaires
- Interface simplifiée pour rejoindre des groupes
- Notifications personnalisées selon les préférences
- Historique détaillé des activités

## 🏗️ Architecture

### Système de Rôles

Le système utilise un système de rôles distincts :

1. **Gérant** (`type: 'gerant'`)
   - Accès complet à toutes les fonctionnalités d'administration
   - Peut créer et gérer des groupes
   - Génère des codes d'invitation
   - Accède aux analyses et rapports

2. **Membre** (`type: 'membre'`)
   - Interface simplifiée pour la participation
   - Peut rejoindre des groupes via des codes d'invitation
   - Suit ses cotisations et sa position dans les rotations
   - Accès limité aux fonctionnalités de gestion

### Flux d'Authentification

```
Connexion → Vérification du type → Redirection vers le bon dashboard
```

- Les gérants sont redirigés vers `dashboard-gerant.html`
- Les membres sont redirigés vers `dashboard-membre.html`
- Le dashboard principal (`dashboard.html`) redirige automatiquement

## 🚀 Installation

1. **Cloner ou télécharger** les fichiers du projet
2. **Ouvrir** `connexion.html` dans un navigateur web
3. **Créer un compte** ou utiliser les comptes de démonstration

### Prérequis

- Navigateur web moderne (Chrome, Firefox, Safari, Edge)
- JavaScript activé
- Connexion internet (pour les polices Google Fonts et Chart.js)

## 📖 Utilisation

### Première Utilisation

1. **Accéder à la page de connexion** (`connexion.html`)
2. **Créer un compte** en choisissant le type d'utilisateur :
   - **Gérant** : Nécessite un code administrateur valide
   - **Membre** : Peut rejoindre des groupes existants
3. **Se connecter** avec les identifiants créés
4. **Accéder au dashboard** approprié

### Codes Administrateur

Pour créer un compte gérant, utilisez l'un de ces codes :
- `ADMIN-2024-001`
- `ADMIN-2024-002`
- `ADMIN-2024-003`
- `KY-ADM-2024-001`
- `KY-ADM-2024-002`

### Fonctionnement des Groupes

1. **Création** : Un gérant crée un groupe avec les paramètres souhaités
2. **Invitation** : Le gérant génère des codes d'invitation
3. **Adhésion** : Les membres rejoignent avec les codes
4. **Gestion** : Le gérant suit les cotisations et effectue les rotations
5. **Participation** : Les membres effectuent leurs cotisations

## 📁 Structure des Fichiers

```
koyako/
├── connexion.html          # Page de connexion/inscription
├── connexion.js            # Logique d'authentification
├── connexion.css           # Styles de la page de connexion
├── dashboard.html          # Dashboard principal (redirection)
├── dashboard.js            # Logique du dashboard principal
├── dashboard-gerant.html   # Dashboard spécifique aux gérants
├── dashboard-membre.html   # Dashboard spécifique aux membres
├── dashboard-membre.js     # Logique du dashboard membre
├── tableau-bord.css        # Styles des dashboards
├── demo.html              # Page de démonstration
└── README.md              # Documentation
```

## 🎮 Comptes de Démonstration

### Compte Gérant
- **Email** : `jean.mukendi@email.com`
- **Mot de passe** : `password123`
- **Type** : Gérant
- **Fonctionnalités** : Accès complet à toutes les fonctionnalités d'administration

### Compte Membre
- **Email** : `marie.kabila@email.com`
- **Mot de passe** : `password123`
- **Type** : Membre
- **Fonctionnalités** : Interface simplifiée pour la participation

### Compte Gérant Supplémentaire
- **Email** : `paul.tshisekedi@email.com`
- **Mot de passe** : `password123`
- **Type** : Gérant

## 🛠️ Technologies Utilisées

### Frontend
- **HTML5** : Structure sémantique et accessible
- **CSS3** : Styles modernes avec variables CSS et Flexbox/Grid
- **JavaScript (ES6+)** : Logique interactive et gestion d'état
- **Chart.js** : Graphiques et visualisations de données

### Design
- **Inter** : Police moderne et lisible
- **CSS Grid & Flexbox** : Layouts responsifs
- **Variables CSS** : Système de design cohérent
- **Animations CSS** : Transitions fluides

### Fonctionnalités
- **LocalStorage** : Persistance des données utilisateur
- **Responsive Design** : Compatible mobile et desktop
- **Accessibilité** : Conforme aux standards WCAG
- **Validation** : Validation côté client des formulaires

## 🔧 Fonctionnalités Techniques

### Sécurité
- Validation des codes administrateur
- Vérification des types d'utilisateur
- Protection contre l'accès non autorisé
- Validation des formulaires

### Performance
- Chargement optimisé des ressources
- Animations fluides
- Interface réactive
- Gestion efficace de l'état

### Expérience Utilisateur
- Interface intuitive et moderne
- Navigation claire et logique
- Feedback visuel immédiat
- Notifications contextuelles

## 🎨 Design System

### Couleurs
- **Primaire** : `#4F46E5` (Bleu)
- **Secondaire** : `#10B981` (Vert)
- **Accent** : `#F59E0B` (Orange)
- **Danger** : `#EF4444` (Rouge)
- **Succès** : `#10B981` (Vert)

### Typographie
- **Famille** : Inter (Google Fonts)
- **Poids** : 300, 400, 500, 600, 700
- **Hiérarchie** : Titres, sous-titres, corps de texte

### Composants
- **Cartes** : Conteneurs avec ombres et bordures arrondies
- **Boutons** : Styles primaire et secondaire
- **Formulaires** : Validation visuelle et feedback
- **Tableaux** : Données structurées et lisibles

## 🚀 Développement

### Ajout de Nouvelles Fonctionnalités

1. **Dashboard Gérant** : Ajouter dans `dashboard-gerant.html` et `dashboard.js`
2. **Dashboard Membre** : Ajouter dans `dashboard-membre.html` et `dashboard-membre.js`
3. **Styles** : Utiliser les variables CSS dans `tableau-bord.css`

### Personnalisation

- **Couleurs** : Modifier les variables CSS dans `:root`
- **Fonctionnalités** : Étendre les scripts JavaScript
- **Données** : Adapter les données simulées selon les besoins

## 📞 Support

Pour toute question ou suggestion d'amélioration :
- Vérifiez la documentation
- Testez avec les comptes de démonstration
- Consultez les commentaires dans le code

---

**🔷 Koyako** - Simplifiez la gestion de vos tontines avec une interface moderne et intuitive ! 