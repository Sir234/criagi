"""
Koyako Backend - Système de gestion des tontines
Ce module gère la logique métier pour les caisses communautaires
"""

import json
import datetime
import uuid
import hashlib
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
from enum import Enum

class UserType(Enum):
    ADMIN = "admin"
    MEMBER = "member"

class GroupStatus(Enum):
    ACTIVE = "active"
    PENDING = "pending"
    COMPLETED = "completed"
    SUSPENDED = "suspended"

class ContributionType(Enum):
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"

@dataclass
class User:
    id: str
    name: str
    email: str
    phone: str
    user_type: UserType
    created_at: datetime.datetime
    is_active: bool = True
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'email': self.email,
            'phone': self.phone,
            'user_type': self.user_type.value,
            'created_at': self.created_at.isoformat(),
            'is_active': self.is_active
        }

@dataclass
class Group:
    id: str
    name: str
    admin_id: str
    contribution_type: ContributionType
    contribution_amount: float
    max_members: int
    description: str
    status: GroupStatus
    created_at: datetime.datetime
    admin_code: str
    current_round: int = 1
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'admin_id': self.admin_id,
            'contribution_type': self.contribution_type.value,
            'contribution_amount': self.contribution_amount,
            'max_members': self.max_members,
            'description': self.description,
            'status': self.status.value,
            'created_at': self.created_at.isoformat(),
            'admin_code': self.admin_code,
            'current_round': self.current_round
        }

@dataclass
class GroupMember:
    id: str
    group_id: str
    user_id: str
    join_date: datetime.datetime
    turn_number: int
    is_active: bool = True
    total_contributions: float = 0.0
    
    def to_dict(self):
        return {
            'id': self.id,
            'group_id': self.group_id,
            'user_id': self.user_id,
            'join_date': self.join_date.isoformat(),
            'turn_number': self.turn_number,
            'is_active': self.is_active,
            'total_contributions': self.total_contributions
        }

@dataclass
class Contribution:
    id: str
    group_id: str
    user_id: str
    amount: float
    contribution_date: datetime.datetime
    round_number: int
    is_confirmed: bool = False
    
    def to_dict(self):
        return {
            'id': self.id,
            'group_id': self.group_id,
            'user_id': self.user_id,
            'amount': self.amount,
            'contribution_date': self.contribution_date.isoformat(),
            'round_number': self.round_number,
            'is_confirmed': self.is_confirmed
        }

class KoyakoSystem:
    """Système principal de gestion Koyako"""
    
    def __init__(self):
        self.users: Dict[str, User] = {}
        self.groups: Dict[str, Group] = {}
        self.group_members: Dict[str, List[GroupMember]] = {}
        self.contributions: Dict[str, List[Contribution]] = {}
        self.invitations: Dict[str, Dict] = {}
        
        # Initialiser avec des données de test
        self._initialize_test_data()
    
    def _initialize_test_data(self):
        """Initialise le système avec des données de test"""
        
        # Créer des utilisateurs de test
        admin_user = self.create_user(
            "Admin Koyako",
            "admin@koyako.cd",
            "+243123456789",
            UserType.ADMIN
        )
        
        member1 = self.create_user(
            "Marie Kabila",
            "marie.kabila@email.com",
            "+243987654321",
            UserType.MEMBER
        )
        
        member2 = self.create_user(
            "Jean Mukendi",
            "jean.mukendi@email.com",
            "+243555123456",
            UserType.MEMBER
        )
        
        # Créer des groupes de test
        group1 = self.create_group(
            admin_user.id,
            "Famille Kinshasa",
            ContributionType.MONTHLY,
            50000,
            15,
            "Tontine familiale mensuelle"
        )
        
        group2 = self.create_group(
            admin_user.id,
            "Amis du Bureau",
            ContributionType.WEEKLY,
            25000,
            8,
            "Tontine hebdomadaire entre collègues"
        )
        
        # Ajouter des membres aux groupes
        self.add_member_to_group(group1.id, member1.id)
        self.add_member_to_group(group1.id, member2.id)
        self.add_member_to_group(group2.id, member1.id)
        
        print("✅ Système Koyako initialisé avec des données de test")
        print(f"👤 Utilisateurs créés: {len(self.users)}")
        print(f"👥 Groupes créés: {len(self.groups)}")
    
    def generate_id(self) -> str:
        """Génère un ID unique"""
        return str(uuid.uuid4())
    
    def generate_admin_code(self) -> str:
        """Génère un code administrateur unique"""
        prefix = "KY-ADM"
        year = datetime.datetime.now().year
        random_part = str(uuid.uuid4())[:8].upper()
        return f"{prefix}-{year}-{random_part}"
    
    def generate_invite_code(self, group_id: str) -> str:
        """Génère un code d'invitation pour un groupe"""
        prefix = "KY-INV"
        year = datetime.datetime.now().year
        group_code = group_id[:6].upper()
        return f"{prefix}-{year}-{group_code}"
    
    def create_user(self, name: str, email: str, phone: str, user_type: UserType) -> User:
        """Crée un nouvel utilisateur"""
        user_id = self.generate_id()
        user = User(
            id=user_id,
            name=name,
            email=email,
            phone=phone,
            user_type=user_type,
            created_at=datetime.datetime.now()
        )
        self.users[user_id] = user
        print(f"✅ Utilisateur créé: {name} ({user_type.value})")
        return user
    
    def create_group(self, admin_id: str, name: str, contribution_type: ContributionType, 
                    contribution_amount: float, max_members: int, description: str) -> Group:
        """Crée un nouveau groupe"""
        if admin_id not in self.users:
            raise ValueError("Administrateur non trouvé")
        
        if self.users[admin_id].user_type != UserType.ADMIN:
            raise ValueError("Seuls les administrateurs peuvent créer des groupes")
        
        group_id = self.generate_id()
        admin_code = self.generate_admin_code()
        
        group = Group(
            id=group_id,
            name=name,
            admin_id=admin_id,
            contribution_type=contribution_type,
            contribution_amount=contribution_amount,
            max_members=max_members,
            description=description,
            status=GroupStatus.ACTIVE,
            created_at=datetime.datetime.now(),
            admin_code=admin_code
        )
        
        self.groups[group_id] = group
        self.group_members[group_id] = []
        self.contributions[group_id] = []
        
        # L'admin devient automatiquement le premier membre
        self.add_member_to_group(group_id, admin_id)
        
        print(f"✅ Groupe créé: {name}")
        print(f"🔑 Code administrateur: {admin_code}")
        
        return group
    
    def add_member_to_group(self, group_id: str, user_id: str) -> bool:
        """Ajoute un membre à un groupe"""
        if group_id not in self.groups:
            raise ValueError("Groupe non trouvé")
        
        if user_id not in self.users:
            raise ValueError("Utilisateur non trouvé")
        
        group = self.groups[group_id]
        current_members = len(self.group_members[group_id])
        
        if current_members >= group.max_members:
            raise ValueError("Groupe complet")
        
        # Vérifier si l'utilisateur est déjà membre
        for member in self.group_members[group_id]:
            if member.user_id == user_id:
                raise ValueError("Utilisateur déjà membre du groupe")
        
        member_id = self.generate_id()
        turn_number = current_members + 1
        
        group_member = GroupMember(
            id=member_id,
            group_id=group_id,
            user_id=user_id,
            join_date=datetime.datetime.now(),
            turn_number=turn_number
        )
        
        self.group_members[group_id].append(group_member)
        
        user_name = self.users[user_id].name
        print(f"✅ {user_name} ajouté au groupe {group.name} (Tour #{turn_number})")
        
        return True
    
    def create_invitation(self, group_id: str, admin_id: str, invitee_email: str) -> str:
        """Crée une invitation pour rejoindre un groupe"""
        if group_id not in self.groups:
            raise ValueError("Groupe non trouvé")
        
        group = self.groups[group_id]
        if group.admin_id != admin_id:
            raise ValueError("Seul l'administrateur peut inviter des membres")
        
        invite_code = self.generate_invite_code(group_id)
        
        invitation = {
            'id': self.generate_id(),
            'group_id': group_id,
            'admin_id': admin_id,
            'invitee_email': invitee_email,
            'invite_code': invite_code,
            'created_at': datetime.datetime.now().isoformat(),
            'is_used': False
        }
        
        self.invitations[invite_code] = invitation
        
        print(f"📧 Invitation créée pour {invitee_email}")
        print(f"🎫 Code d'invitation: {invite_code}")
        
        return invite_code
    
    def join_group_with_code(self, user_id: str, invite_code: str) -> bool:
        """Permet à un utilisateur de rejoindre un groupe avec un code d'invitation"""
        if invite_code not in self.invitations:
            raise ValueError("Code d'invitation invalide")
        
        invitation = self.invitations[invite_code]
        
        if invitation['is_used']:
            raise ValueError("Code d'invitation déjà utilisé")
        
        group_id = invitation['group_id']
        
        # Ajouter le membre au groupe
        self.add_member_to_group(group_id, user_id)
        
        # Marquer l'invitation comme utilisée
        invitation['is_used'] = True
        invitation['used_by'] = user_id
        invitation['used_at'] = datetime.datetime.now().isoformat()
        
        user_name = self.users[user_id].name
        group_name = self.groups[group_id].name
        print(f"🎉 {user_name} a rejoint le groupe {group_name}")
        
        return True
    
    def record_contribution(self, group_id: str, user_id: str, amount: float) -> Contribution:
        """Enregistre une cotisation"""
        if group_id not in self.groups:
            raise ValueError("Groupe non trouvé")
        
        if user_id not in self.users:
            raise ValueError("Utilisateur non trouvé")
        
        group = self.groups[group_id]
        
        # Vérifier que l'utilisateur est membre du groupe
        is_member = False
        for member in self.group_members[group_id]:
            if member.user_id == user_id:
                is_member = True
                member.total_contributions += amount
                break
        
        if not is_member:
            raise ValueError("Utilisateur non membre du groupe")
        
        contribution_id = self.generate_id()
        contribution = Contribution(
            id=contribution_id,
            group_id=group_id,
            user_id=user_id,
            amount=amount,
            contribution_date=datetime.datetime.now(),
            round_number=group.current_round
        )
        
        self.contributions[group_id].append(contribution)
        
        user_name = self.users[user_id].name
        print(f"💰 Cotisation enregistrée: {user_name} - {amount:,.0f} FC")
        
        return contribution
    
    def get_group_statistics(self, group_id: str) -> Dict:
        """Obtient les statistiques d'un groupe"""
        if group_id not in self.groups:
            raise ValueError("Groupe non trouvé")
        
        group = self.groups[group_id]
        members = self.group_members[group_id]
        contributions = self.contributions[group_id]
        
        total_contributions = sum(c.amount for c in contributions)
        total_members = len(members)
        active_members = len([m for m in members if m.is_active])
        
        # Calculer le taux de participation
        expected_contributions = group.contribution_amount * total_members * group.current_round
        participation_rate = (total_contributions / expected_contributions * 100) if expected_contributions > 0 else 0
        
        stats = {
            'group_name': group.name,
            'total_members': total_members,
            'active_members': active_members,
            'total_contributions': total_contributions,
            'expected_contributions': expected_contributions,
            'participation_rate': round(participation_rate, 2),
            'current_round': group.current_round,
            'contribution_amount': group.contribution_amount,
            'status': group.status.value
        }
        
        return stats
    
    def get_user_groups(self, user_id: str) -> List[Dict]:
        """Obtient tous les groupes d'un utilisateur"""
        if user_id not in self.users:
            raise ValueError("Utilisateur non trouvé")
        
        user_groups = []
        
        for group_id, group in self.groups.items():
            # Vérifier si l'utilisateur est membre
            for member in self.group_members[group_id]:
                if member.user_id == user_id:
                    group_info = group.to_dict()
                    group_info['member_info'] = member.to_dict()
                    group_info['total_members'] = len(self.group_members[group_id])
                    user_groups.append(group_info)
                    break
        
        return user_groups
    
    def get_member_performance(self, group_id: str) -> List[Dict]:
        """Obtient les performances des membres d'un groupe"""
        if group_id not in self.groups:
            raise ValueError("Groupe non trouvé")
        
        group = self.groups[group_id]
        members = self.group_members[group_id]
        contributions = self.contributions[group_id]
        
        performance_data = []
        
        for member in members:
            user = self.users[member.user_id]
            member_contributions = [c for c in contributions if c.user_id == member.user_id]
            
            total_paid = sum(c.amount for c in member_contributions)
            expected_amount = group.contribution_amount * group.current_round
            payment_rate = (total_paid / expected_amount * 100) if expected_amount > 0 else 0
            
            performance = {
                'user_name': user.name,
                'user_email': user.email,
                'turn_number': member.turn_number,
                'total_contributions': total_paid,
                'expected_contributions': expected_amount,
                'payment_rate': round(payment_rate, 2),
                'is_active': member.is_active,
                'join_date': member.join_date.isoformat()
            }
            
            performance_data.append(performance)
        
        # Trier par taux de paiement décroissant
        performance_data.sort(key=lambda x: x['payment_rate'], reverse=True)
        
        return performance_data

# Démonstration du système
def demo_koyako_system():
    """Démonstration complète du système Koyako"""
    print("🔷 === DÉMONSTRATION SYSTÈME KOYAKO === 🔷\n")
    
    # Initialiser le système
    koyako = KoyakoSystem()
    
    print("\n📊 === STATISTIQUES INITIALES ===")
    
    # Obtenir les groupes de l'admin
    admin_id = list(koyako.users.keys())[0]  # Premier utilisateur (admin)
    admin_groups = koyako.get_user_groups(admin_id)
    
    for group_data in admin_groups:
        group_id = group_data['id']
        stats = koyako.get_group_statistics(group_id)
        
        print(f"\n📈 Groupe: {stats['group_name']}")
        print(f"   👥 Membres: {stats['active_members']}/{stats['total_members']}")
        print(f"   💰 Cotisations: {stats['total_contributions']:,.0f} FC")
        print(f"   📊 Taux de participation: {stats['participation_rate']}%")
    
    print("\n🎯 === SIMULATION D'ACTIVITÉS ===")
    
    # Simuler des cotisations
    group_id = list(koyako.groups.keys())[0]  # Premier groupe
    members = koyako.group_members[group_id]
    
    for member in members[:2]:  # Premières cotisations
        amount = koyako.groups[group_id].contribution_amount
        koyako.record_contribution(group_id, member.user_id, amount)
    
    print("\n📈 === PERFORMANCES DES MEMBRES ===")
    
    # Afficher les performances
    performance = koyako.get_member_performance(group_id)
    for perf in performance:
        print(f"👤 {perf['user_name']}: {perf['payment_rate']}% de ponctualité")
    
    print("\n🎫 === TEST D'INVITATION ===")
    
    # Créer une invitation
    invite_code = koyako.create_invitation(
        group_id, 
        admin_id, 
        "nouveau.membre@email.com"
    )
    
    # Créer un nouveau membre et le faire rejoindre
    new_member = koyako.create_user(
        "Grace Mbuyi",
        "grace.mbuyi@email.com",
        "+243777888999",
        UserType.MEMBER
    )
    
    koyako.join_group_with_code(new_member.id, invite_code)
    
    print("\n📊 === STATISTIQUES FINALES ===")
    
    # Statistiques finales
    final_stats = koyako.get_group_statistics(group_id)
    print(f"📈 Groupe: {final_stats['group_name']}")
    print(f"   👥 Membres: {final_stats['active_members']}/{final_stats['total_members']}")
    print(f"   💰 Total collecté: {final_stats['total_contributions']:,.0f} FC")
    print(f"   📊 Taux de participation: {final_stats['participation_rate']}%")
    
    print("\n✅ === DÉMONSTRATION TERMINÉE ===")
    
    return koyako

# Exécuter la démonstration
if __name__ == "__main__":
    system = demo_koyako_system()
