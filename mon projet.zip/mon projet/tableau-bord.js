// === SCRIPT DU TABLEAU DE BORD KOYAKO ===

// Variables globales pour la gestion des données
let utilisateurActuel = null
let groupes = []
let membres = []
let activites = []
let graphiques = {}
let tourActuel = 1
let rotationData = []

// Initialisation au chargement de la page
document.addEventListener('DOMContentLoaded', () => {
  console.log('🔷 Initialisation du tableau de bord Koyako...')
  
  verifierAuthentification()
  initialiserTableauDeBord()
  chargerDonneesSimulees()
  initialiserGraphiques()
  configurerGestionnaireEvenements()
  initialiserRotation()
  
  console.log('✅ Tableau de bord initialisé avec succès!')
})

// Vérifier l'authentification de l'utilisateur
function verifierAuthentification() {
  const donneesUtilisateur = localStorage.getItem('koyako_utilisateur')
  if (!donneesUtilisateur) {
    afficherNotification('Session expirée. Redirection...', 'erreur')
    setTimeout(() => {
      window.location.href = 'accueil.html'
    }, 2000)
    return
  }

  utilisateurActuel = JSON.parse(donneesUtilisateur)
  console.log('Utilisateur connecté:', utilisateurActuel)
}

// Initialiser le tableau de bord selon le type d'utilisateur
function initialiserTableauDeBord() {
  // Afficher le nom de l'utilisateur
  const nomUtilisateur = utilisateurActuel.nom || utilisateurActuel.prenom + ' ' + utilisateurActuel.nom || 'Utilisateur'
  document.getElementById('nom-utilisateur').textContent = nomUtilisateur

  // Configurer l'interface selon le type d'utilisateur
  const roleElement = document.getElementById('role-utilisateur')
  if (utilisateurActuel.type === 'admin') {
    roleElement.textContent = 'Administrateur'
    roleElement.style.background = '#dc2626'
    
    // Afficher le code admin
    const codeAdmin = genererCodeAdmin()
    document.getElementById('code-admin-affiche').textContent = codeAdmin
    document.getElementById('code-admin-container').style.display = 'block'
    
    // Afficher les éléments admin
    document.getElementById('nav-gestion').style.display = 'block'
    document.getElementById('nav-creer').style.display = 'block'
    document.getElementById('nav-invitations').style.display = 'block'
    document.getElementById('nav-analyses').style.display = 'block'
    
    localStorage.setItem('code-admin', codeAdmin)
  } else {
    roleElement.textContent = 'Membre'
    roleElement.style.background = '#10b981'
  }
}

// Générer un code administrateur unique
function genererCodeAdmin() {
  const prefixe = 'KY-ADM'
  const annee = new Date().getFullYear()
  const aleatoire = Math.floor(Math.random() * 1000).toString().padStart(3, '0')
  return `${prefixe}-${annee}-${aleatoire}`
}

// Charger des données simulées pour la démonstration
function chargerDonneesSimulees() {
  // Données simulées des groupes
  groupes = [
    {
      id: 1,
      nom: 'Famille Kinshasa',
      type: 'mensuelle',
      membres: 15,
      montant: 50000,
      statut: 'actif',
      dateCreation: '2024-01-15',
      description: 'Tontine familiale mensuelle pour les projets communs',
      tourActuel: 3,
      beneficiaireActuel: 'Marie Kabila',
      prochainTour: '2024-04-15'
    },
    {
      id: 2,
      nom: 'Amis du Bureau',
      type: 'hebdomadaire',
      membres: 8,
      montant: 25000,
      statut: 'actif',
      dateCreation: '2024-02-01',
      description: 'Tontine hebdomadaire entre collègues de travail',
      tourActuel: 12,
      beneficiaireActuel: 'Jean Mukendi',
      prochainTour: '2024-03-25'
    },
    {
      id: 3,
      nom: 'Groupe Église',
      type: 'mensuelle',
      membres: 12,
      montant: 75000,
      statut: 'actif',
      dateCreation: '2024-02-15',
      description: 'Tontine de la communauté religieuse',
      tourActuel: 2,
      beneficiaireActuel: 'Grace Mbuyi',
      prochainTour: '2024-04-20'
    }
  ]

  // Données simulées des activités récentes
  activites = [
    {
      id: 1,
      type: 'rotation',
      message: 'Rotation effectuée - Marie Kabila est la nouvelle bénéficiaire',
      temps: 'Il y a 2 heures',
      icone: '🔄'
    },
    {
      id: 2,
      type: 'cotisation',
      message: 'Jean Mukendi a effectué sa cotisation (25,000 FC)',
      temps: 'Il y a 4 heures',
      icone: '💰'
    },
    {
      id: 3,
      type: 'nouveau-membre',
      message: 'Grace Mbuyi a rejoint le groupe Église',
      temps: 'Il y a 1 jour',
      icone: '👤'
    },
    {
      id: 4,
      type: 'rappel',
      message: 'Rappel envoyé pour les cotisations du groupe Famille',
      temps: 'Il y a 2 jours',
      icone: '🔔'
    }
  ]

  // Mettre à jour l'affichage
  mettreAJourStatistiques()
  chargerGroupes()
  chargerActivitesRecentes()
  genererCalendrierRotation()
}

// Mettre à jour les statistiques du tableau de bord
function mettreAJourStatistiques() {
  document.getElementById('total-groupes').textContent = groupes.length
  
  const totalMembres = groupes.reduce((somme, groupe) => somme + groupe.membres, 0)
  document.getElementById('total-membres').textContent = totalMembres

  const montantTotal = groupes.reduce((somme, groupe) => somme + (groupe.montant * groupe.membres), 0)
  document.getElementById('total-montant').textContent = montantTotal.toLocaleString()

  // Calculer le prochain tour de l'utilisateur (simulation)
  const monProchainTour = Math.floor(Math.random() * 10) + 1
  document.getElementById('mon-tour').textContent = monProchainTour
}

// Charger et afficher la liste des groupes
function chargerGroupes() {
  const listeGroupes = document.getElementById('liste-groupes')
  if (!listeGroupes) return

  listeGroupes.innerHTML = ''

  groupes.forEach(groupe => {
    const carteGroupe = document.createElement('div')
    carteGroupe.className = 'group-card'
    carteGroupe.innerHTML = `
      <div class="group-header">
        <h3>${groupe.nom}</h3>
        <span class="group-status status-${groupe.statut}">
          ${groupe.statut === 'actif' ? 'Actif' : groupe.statut === 'en-attente' ? 'En attente' : 'Terminé'}
        </span>
      </div>
      
      <div class="group-info">
        <p><strong>Type:</strong> ${getTypeLabel(groupe.type)}</p>
        <p><strong>Membres:</strong> ${groupe.membres}</p>
        <p><strong>Cotisation:</strong> ${groupe.montant.toLocaleString()} FC</p>
        <p><strong>Tour actuel:</strong> ${groupe.tourActuel}</p>
        <p><strong>Bénéficiaire:</strong> ${groupe.beneficiaireActuel}</p>
        <p><strong>Prochain tour:</strong> ${formatDate(groupe.prochainTour)}</p>
      </div>
      
      <div class="group-actions">
        <button class="btn-primary btn-small" onclick="voirDetailsGroupe(${groupe.id})">
          Voir détails
        </button>
        <button class="btn-secondary btn-small" onclick="effectuerRotationGroupe(${groupe.id})">
          🔄 Rotation
        </button>
      </div>
    `
    listeGroupes.appendChild(carteGroupe)
  })
}

// Charger et afficher les activités récentes
function chargerActivitesRecentes() {
  const listeActivites = document.getElementById('liste-activites')
  if (!listeActivites) return

  listeActivites.innerHTML = ''

  activites.forEach(activite => {
    const itemActivite = document.createElement('div')
    itemActivite.className = 'activity-item'
    itemActivite.innerHTML = `
      <div class="activity-icon">${activite.icone}</div>
      <div class="activity-content">
        <p>${activite.message}</p>
        <div class="activity-time">${activite.temps}</div>
      </div>
    `
    listeActivites.appendChild(itemActivite)
  })
}

// Initialiser le système de rotation
function initialiserRotation() {
  // Mettre à jour les informations de rotation
  const groupePrincipal = groupes[0] // Premier groupe comme exemple
  if (groupePrincipal) {
    document.getElementById('tour-actuel').textContent = `Tour ${groupePrincipal.tourActuel}`
    document.getElementById('date-tour').textContent = new Date().toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' })
    document.getElementById('prochaine-rotation').textContent = formatDate(groupePrincipal.prochainTour)
    document.getElementById('nom-beneficiaire').textContent = groupePrincipal.beneficiaireActuel
    document.getElementById('groupe-beneficiaire').textContent = groupePrincipal.nom
    document.getElementById('montant-beneficiaire').textContent = (groupePrincipal.montant * groupePrincipal.membres).toLocaleString() + ' FC'
  }

  chargerGroupesRotation()
}

// Générer le calendrier de rotation
function genererCalendrierRotation() {
  const timelineContainer = document.getElementById('timeline-rotations')
  if (!timelineContainer) return

  timelineContainer.innerHTML = ''

  // Générer 6 mois de rotations
  for (let i = 0; i < 6; i++) {
    const date = new Date()
    date.setMonth(date.getMonth() + i)
    
    const timelineItem = document.createElement('div')
    timelineItem.className = `timeline-item ${i === 0 ? 'current' : i < 2 ? 'completed' : ''}`
    
    const beneficiaires = ['Marie Kabila', 'Jean Mukendi', 'Grace Mbuyi', 'Paul Tshisekedi', 'David Kasongo', 'Sarah Lumumba']
    const beneficiaire = beneficiaires[i % beneficiaires.length]
    
    timelineItem.innerHTML = `
      <div class="timeline-date">
        ${date.toLocaleDateString('fr-FR', { month: 'short', year: 'numeric' })}
      </div>
      <div class="timeline-info">
        <h4>${beneficiaire}</h4>
        <p>Bénéficiaire du tour ${i + 1}</p>
      </div>
    `
    
    timelineContainer.appendChild(timelineItem)
  }
}

// Charger les groupes avec rotation active
function chargerGroupesRotation() {
  const groupesRotation = document.getElementById('groupes-rotation')
  if (!groupesRotation) return

  groupesRotation.innerHTML = ''

  groupes.forEach(groupe => {
    const groupeItem = document.createElement('div')
    groupeItem.className = 'rotation-group-item'
    groupeItem.innerHTML = `
      <h4>${groupe.nom}</h4>
      <p>Tour actuel: ${groupe.tourActuel}</p>
      <p>Bénéficiaire: ${groupe.beneficiaireActuel}</p>
      <p>Prochain tour: ${formatDate(groupe.prochainTour)}</p>
    `
    groupesRotation.appendChild(groupeItem)
  })
}

// Effectuer une rotation manuelle
function effectuerRotation() {
  if (confirm('Êtes-vous sûr de vouloir effectuer la rotation maintenant ?')) {
    // Simuler la rotation
    groupes.forEach(groupe => {
      groupe.tourActuel += 1
      
      // Changer le bénéficiaire (simulation)
      const beneficiaires = ['Marie Kabila', 'Jean Mukendi', 'Grace Mbuyi', 'Paul Tshisekedi', 'David Kasongo']
      const indexActuel = beneficiaires.indexOf(groupe.beneficiaireActuel)
      const nouveauIndex = (indexActuel + 1) % beneficiaires.length
      groupe.beneficiaireActuel = beneficiaires[nouveauIndex]
      
      // Mettre à jour la date du prochain tour
      const nouvelleDate = new Date(groupe.prochainTour)
      if (groupe.type === 'hebdomadaire') {
        nouvelleDate.setDate(nouvelleDate.getDate() + 7)
      } else if (groupe.type === 'mensuelle') {
        nouvelleDate.setMonth(nouvelleDate.getMonth() + 1)
      } else {
        nouvelleDate.setMonth(nouvelleDate.getMonth() + 3)
      }
      groupe.prochainTour = nouvelleDate.toISOString().split('T')[0]
    })

    // Ajouter une nouvelle activité
    activites.unshift({
      id: activites.length + 1,
      type: 'rotation',
      message: `Rotation manuelle effectuée - Nouveaux bénéficiaires désignés`,
      temps: 'À l\'instant',
      icone: '🔄'
    })

    // Mettre à jour l'affichage
    chargerGroupes()
    chargerActivitesRecentes()
    initialiserRotation()
    genererCalendrierRotation()

    afficherNotification('Rotation effectuée avec succès !', 'succes')
  }
}

// Effectuer rotation pour un groupe spécifique
function effectuerRotationGroupe(groupeId) {
  const groupe = groupes.find(g => g.id === groupeId)
  if (!groupe) return

  if (confirm(`Effectuer la rotation pour le groupe "${groupe.nom}" ?`)) {
    // Simuler la rotation pour ce groupe
    groupe.tourActuel += 1
    
    const beneficiaires = ['Marie Kabila', 'Jean Mukendi', 'Grace Mbuyi', 'Paul Tshisekedi', 'David Kasongo']
    const indexActuel = beneficiaires.indexOf(groupe.beneficiaireActuel)
    const nouveauIndex = (indexActuel + 1) % beneficiaires.length
    const ancienBeneficiaire = groupe.beneficiaireActuel
    groupe.beneficiaireActuel = beneficiaires[nouveauIndex]

    // Ajouter une activité
    activites.unshift({
      id: activites.length + 1,
      type: 'rotation',
      message: `Rotation dans ${groupe.nom} - ${groupe.beneficiaireActuel} remplace ${ancienBeneficiaire}`,
      temps: 'À l\'instant',
      icone: '🔄'
    })

    // Mettre à jour l'affichage
    chargerGroupes()
    chargerActivitesRecentes()
    initialiserRotation()

    afficherNotification(`Rotation effectuée pour ${groupe.nom}`, 'succes')
  }
}

// Voir les détails d'un groupe
function voirDetailsGroupe(groupeId) {
  const groupe = groupes.find(g => g.id === groupeId)
  if (!groupe) return

  alert(
    `Détails du groupe: ${groupe.nom}\n` +
    `Type: ${getTypeLabel(groupe.type)}\n` +
    `Membres: ${groupe.membres}\n` +
    `Cotisation: ${groupe.montant.toLocaleString()} FC\n` +
    `Tour actuel: ${groupe.tourActuel}\n` +
    `Bénéficiaire actuel: ${groupe.beneficiaireActuel}\n` +
    `Prochain tour: ${formatDate(groupe.prochainTour)}\n` +
    `Description: ${groupe.description}`
  )
}

// Initialiser les graphiques
function initialiserGraphiques() {
  // Graphique des cotisations
  const ctxCotisations = document.getElementById('graphique-cotisations')
  if (ctxCotisations) {
    graphiques.cotisations = new Chart(ctxCotisations, {
      type: 'line',
      data: {
        labels: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Jun'],
        datasets: [{
          label: 'Cotisations (FC)',
          data: [800000, 950000, 1100000, 1250000, 1150000, 1250000],
          borderColor: '#2563eb',
          backgroundColor: 'rgba(37, 99, 235, 0.1)',
          tension: 0.4
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            display: false
          }
        },
        scales: {
          y: {
            beginAtZero: true,
            ticks: {
              callback: function(value) {
                return value.toLocaleString() + ' FC'
              }
            }
          }
        }
      }
    })
  }

  // Graphique des groupes
  const ctxGroupes = document.getElementById('graphique-groupes')
  if (ctxGroupes) {
    graphiques.groupes = new Chart(ctxGroupes, {
      type: 'doughnut',
      data: {
        labels: groupes.map(g => g.nom),
        datasets: [{
          data: groupes.map(g => g.montant * g.membres),
          backgroundColor: [
            '#2563eb',
            '#10b981',
            '#f59e0b',
            '#ef4444',
            '#8b5cf6'
          ]
        }]
      },
      options: {
        responsive: true,
        plugins: {
          legend: {
            position: 'bottom'
          }
        }
      }
    })
  }
}

// Configurer les gestionnaires d'événements
function configurerGestionnaireEvenements() {
  // Filtres pour les groupes
  const filtreStatut = document.getElementById('filtre-statut')
  const rechercheGroupe = document.getElementById('recherche-groupe')

  if (filtreStatut) {
    filtreStatut.addEventListener('change', filtrerGroupes)
  }

  if (rechercheGroupe) {
    rechercheGroupe.addEventListener('input', filtrerGroupes)
  }

  // Formulaire de paramètres
  const formulaireParametres = document.getElementById('formulaire-parametres')
  if (formulaireParametres) {
    formulaireParametres.addEventListener('submit', sauvegarderParametres)
    
    // Pré-remplir les champs
    document.getElementById('nom-utilisateur-param').value = utilisateurActuel.nom || ''
    document.getElementById('email-utilisateur-param').value = utilisateurActuel.email || ''
    document.getElementById('telephone-utilisateur-param').value = utilisateurActuel.telephone || ''
  }
}

// Filtrer les groupes
function filtrerGroupes() {
  const filtreStatut = document.getElementById('filtre-statut').value
  const rechercheTexte = document.getElementById('recherche-groupe').value.toLowerCase()

  let groupesFiltres = groupes

  if (filtreStatut) {
    groupesFiltres = groupesFiltres.filter(g => g.statut === filtreStatut)
  }

  if (rechercheTexte) {
    groupesFiltres = groupesFiltres.filter(g => 
      g.nom.toLowerCase().includes(rechercheTexte) ||
      g.description.toLowerCase().includes(rechercheTexte)
    )
  }

  // Réafficher les groupes filtrés
  const listeGroupes = document.getElementById('liste-groupes')
  if (listeGroupes) {
    listeGroupes.innerHTML = ''
    groupesFiltres.forEach(groupe => {
      const carteGroupe = document.createElement('div')
      carteGroupe.className = 'group-card'
      carteGroupe.innerHTML = `
        <div class="group-header">
          <h3>${groupe.nom}</h3>
          <span class="group-status status-${groupe.statut}">
            ${groupe.statut === 'actif' ? 'Actif' : groupe.statut === 'en-attente' ? 'En attente' : 'Terminé'}
          </span>
        </div>
        
        <div class="group-info">
          <p><strong>Type:</strong> ${getTypeLabel(groupe.type)}</p>
          <p><strong>Membres:</strong> ${groupe.membres}</p>
          <p><strong>Cotisation:</strong> ${groupe.montant.toLocaleString()} FC</p>
          <p><strong>Tour actuel:</strong> ${groupe.tourActuel}</p>
          <p><strong>Bénéficiaire:</strong> ${groupe.beneficiaireActuel}</p>
        </div>
        
        <div class="group-actions">
          <button class="btn-primary btn-small" onclick="voirDetailsGroupe(${groupe.id})">
            Voir détails
          </button>
          <button class="btn-secondary btn-small" onclick="effectuerRotationGroupe(${groupe.id})">
            🔄 Rotation
          </button>
        </div>
      `
      listeGroupes.appendChild(carteGroupe)
    })
  }
}

// Sauvegarder les paramètres
function sauvegarderParametres(e) {
  e.preventDefault()

  const nouveauNom = document.getElementById('nom-utilisateur-param').value
  const nouvelEmail = document.getElementById('email-utilisateur-param').value
  const nouveauTelephone = document.getElementById('telephone-utilisateur-param').value

  // Mettre à jour les données utilisateur
  utilisateurActuel.nom = nouveauNom
  utilisateurActuel.email = nouvelEmail
  utilisateurActuel.telephone = nouveauTelephone

  // Sauvegarder dans localStorage
  localStorage.setItem('koyako_utilisateur', JSON.stringify(utilisateurActuel))

  // Mettre à jour l'affichage
  document.getElementById('nom-utilisateur').textContent = nouveauNom

  afficherNotification('Paramètres sauvegardés avec succès !', 'succes')
}

// Navigation entre les sections
function afficherSection(nomSection) {
  // Masquer toutes les sections
  document.querySelectorAll('.dashboard-section').forEach(section => {
    section.classList.remove('active')
  })

  // Retirer la classe active de tous les liens de navigation
  document.querySelectorAll('.nav-item').forEach(item => {
    item.classList.remove('active')
  })

  // Afficher la section sélectionnée
  const section = document.getElementById(`section-${nomSection}`)
  if (section) {
    section.classList.add('active')
  }

  // Ajouter la classe active au lien de navigation
  const navItem = document.querySelector(`[onclick="afficherSection('${nomSection}')"]`)
  if (navItem) {
    navItem.classList.add('active')
  }

  // Mettre à jour le titre de la page
  const titres = {
    'vue-ensemble': 'Vue d\'ensemble',
    'mes-groupes': 'Mes Groupes',
    'gestion-membres': 'Gestion des Membres',
    'creer-groupe': 'Créer un Groupe',
    'rotation-postes': 'Rotation des Postes',
    'invitations': 'Invitations',
    'analyses': 'Analyses',
    'parametres': 'Paramètres'
  }

  const titrePage = document.getElementById('titre-page')
  if (titrePage && titres[nomSection]) {
    titrePage.textContent = titres[nomSection]
  }
}

// Fonctions utilitaires
function getTypeLabel(type) {
  const labels = {
    'hebdomadaire': 'Hebdomadaire',
    'mensuelle': 'Mensuelle',
    'trimestrielle': 'Trimestrielle'
  }
  return labels[type] || type
}

function formatDate(dateString) {
  return new Date(dateString).toLocaleDateString('fr-FR')
}

function afficherNotification(message, type) {
  const notification = document.createElement('div')
  notification.className = `notification notification-${type}`
  notification.textContent = message
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 15px 20px;
    border-radius: 8px;
    color: white;
    font-weight: 500;
    z-index: 9999;
    max-width: 400px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    animation: slideInRight 0.3s ease-out;
  `

  // Couleurs selon le type
  switch (type) {
    case 'succes':
      notification.style.background = '#10b981'
      break
    case 'erreur':
      notification.style.background = '#ef4444'
      break
    case 'avertissement':
      notification.style.background = '#f59e0b'
      break
    default:
      notification.style.background = '#2563eb'
  }

  document.body.appendChild(notification)

  // Suppression automatique
  setTimeout(() => {
    notification.style.animation = 'slideOutRight 0.3s ease-in'
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove()
      }
    }, 300)
  }, 4000)
}

function seDeconnecter() {
  if (confirm('Êtes-vous sûr de vouloir vous déconnecter ?')) {
    localStorage.removeItem('koyako_utilisateur')
    localStorage.removeItem('koyako_se_souvenir')
    window.location.href = 'accueil.html'
  }
}

// Ajouter les styles CSS pour les animations
const style = document.createElement('style')
style.textContent = `
  @keyframes slideInRight {
    from {
      transform: translateX(100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  
  @keyframes slideOutRight {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(100%);
      opacity: 0;
    }
  }
`
document.head.appendChild(style)

console.log('🔷 Script du tableau de bord Koyako chargé avec succès!')
