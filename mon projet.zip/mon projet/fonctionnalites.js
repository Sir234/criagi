// === SCRIPT POUR LA PAGE FONCTIONNALITÉS ===

document.addEventListener('DOMContentLoaded', () => {
  console.log('🛠️ Chargement de la page fonctionnalités Koyako...')
  
  initialiserNavigation()
  initialiserAnimations()
  initialiserDemos()
  
  console.log('✅ Page fonctionnalités chargée avec succès!')
})

// Initialiser la navigation
function initialiserNavigation() {
  const hamburger = document.querySelector('.hamburger')
  const navMenu = document.querySelector('.nav-menu')

  if (hamburger && navMenu) {
    hamburger.addEventListener('click', () => {
      hamburger.classList.toggle('active')
      navMenu.classList.toggle('active')
    })

    document.querySelectorAll('.nav-menu a').forEach(lien => {
      lien.addEventListener('click', () => {
        hamburger.classList.remove('active')
        navMenu.classList.remove('active')
      })
    })
  }

  // Effet de défilement sur la navbar
  window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar')
    if (window.scrollY > 50) {
      navbar.style.background = 'rgba(255, 255, 255, 0.98)'
      navbar.style.boxShadow = '0 2px 20px rgba(0,0,0,0.1)'
    } else {
      navbar.style.background = 'rgba(255, 255, 255, 0.95)'
      navbar.style.boxShadow = 'none'
    }
  })
}

// Initialiser les animations
function initialiserAnimations() {
  // Observer pour les sections de fonctionnalités
  const observerSections = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible')
      }
    })
  }, { threshold: 0.2 })

  // Observer pour les fonctionnalités avancées
  const observerAdvanced = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.classList.add('visible')
        }, index * 100)
      }
    })
  }, { threshold: 0.1 })

  // Observer pour les lignes de comparaison
  const observerComparison = new IntersectionObserver((entries) => {
    entries.forEach((entry, index) => {
      if (entry.isIntersecting) {
        setTimeout(() => {
          entry.target.classList.add('visible')
        }, index * 150)
      }
    })
  }, { threshold: 0.1 })

  // Appliquer les observateurs
  document.querySelectorAll('.feature-section').forEach(section => {
    observerSections.observe(section)
  })

  document.querySelectorAll('.advanced-feature').forEach(feature => {
    observerAdvanced.observe(feature)
  })

  document.querySelectorAll('.comparison-row').forEach(row => {
    observerComparison.observe(row)
  })
}

// Initialiser les démos interactives
function initialiserDemos() {
  // Démo de création de caisse
  initialiserDemoCreation()
  
  // Démo de notifications
  initialiserDemoNotifications()
  
  // Interactions avec les éléments de bénéfice
  initialiserInteractionsBenefices()
}

// Démo de création de caisse
function initialiserDemoCreation() {
  const demoSteps = document.querySelectorAll('.demo-step')
  if (demoSteps.length === 0) return

  let currentStep = 0
  
  // Fonction pour passer à l'étape suivante
  function nextStep() {
    demoSteps[currentStep].classList.remove('active')
    currentStep = (currentStep + 1) % demoSteps.length
    demoSteps[currentStep].classList.add('active')
  }
  
  // Démarrer la démo automatique
  setInterval(nextStep, 3000)
  
  // Permettre le clic pour avancer manuellement
  demoSteps.forEach((step, index) => {
    step.addEventListener('click', () => {
      demoSteps[currentStep].classList.remove('active')
      currentStep = index
      demoSteps[currentStep].classList.add('active')
    })
  })
}

// Démo de notifications
function initialiserDemoNotifications() {
  const notifications = document.querySelectorAll('.notification-item')
  if (notifications.length === 0) return
  
  // Afficher les notifications avec un délai
  notifications.forEach((notif, index) => {
    setTimeout(() => {
      notif.classList.add('visible')
    }, 1000 + index * 1500)
  })
  
  // Animation de notification périodique
  setInterval(() => {
    notifications.forEach(notif => {
      notif.classList.remove('visible')
    })
    
    setTimeout(() => {
      notifications.forEach((notif, index) => {
        setTimeout(() => {
          notif.classList.add('visible')
        }, index * 1500)
      })
    }, 500)
  }, 10000)
}

// Interactions avec les éléments de bénéfice
function initialiserInteractionsBenefices() {
  const benefitItems = document.querySelectorAll('.benefit-item')
  
  benefitItems.forEach(item => {
    item.addEventListener('mouseenter', () => {
      const icon = item.querySelector('.benefit-icon')
      icon.style.transform = 'scale(1.2)'
    })
    
    item.addEventListener('mouseleave', () => {
      const icon = item.querySelector('.benefit-icon')
      icon.style.transform = 'scale(1)'
    })
  })
  
  // Animation pour la carte d'invitation
  const invitationCard = document.querySelector('.invitation-card')
  if (invitationCard) {
    setInterval(() => {
      invitationCard.style.transform = 'scale(1.05)'
      invitationCard.style.transition = 'transform 0.5s ease'
      
      setTimeout(() => {
        invitationCard.style.transform = 'scale(1)'
      }, 500)
    }, 5000)
  }
  
  // Animation pour les statistiques
  const statCards = document.querySelectorAll('.stat-card')
  if (statCards.length > 0) {
    statCards.forEach(card => {
      card.addEventListener('mouseenter', () => {
        card.style.transform = 'translateY(-10px)'
        card.style.boxShadow = '0 15px 30px rgba(0, 0, 0, 0.2)'
      })
      
      card.addEventListener('mouseleave', () => {
        card.style.transform = 'translateY(0)'
        card.style.boxShadow = '0 10px 25px rgba(0, 0, 0, 0.15)'
      })
    })
  }
}

// Effet de parallaxe léger pour la section hero
window.addEventListener('scroll', () => {
  const scrolled = window.pageYOffset
  const hero = document.querySelector('.hero')
  const speed = scrolled * 0.1

  if (hero) {
    hero.style.transform = `translateY(${speed}px)`
  }
})

// Gestion du redimensionnement
window.addEventListener('resize', () => {
  const hamburger = document.querySelector('.hamburger')
  const navMenu = document.querySelector('.nav-menu')
  
  if (window.innerWidth > 768) {
    hamburger?.classList.remove('active')
    navMenu?.classList.remove('active')
  }
})

// Animation des compteurs pour les statistiques
function animerCompteur(element, valeurCible, duree = 2000) {
  let valeurActuelle = 0
  const increment = valeurCible / (duree / 16)
  const texteOriginal = element.textContent
  const suffixe = texteOriginal.replace(/[\d,]/g, '')

  const timer = setInterval(() => {
    valeurActuelle += increment
    const valeurAffichee = Math.floor(valeurActuelle)
    
    if (valeurAffichee >= 1000) {
      element.textContent = (valeurAffichee / 1000).toFixed(0) + 'K' + suffixe.replace(/[\d,K]/g, '')
    } else {
      element.textContent = valeurAffichee.toLocaleString() + suffixe.replace(/[\d,]/g, '')
    }

    if (valeurActuelle >= valeurCible) {
      element.textContent = texteOriginal
      clearInterval(timer)
    }
  }, 16)
}

console.log('🛠️ Script fonctionnalités Koyako chargé!')
