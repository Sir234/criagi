// === SCRIPT D'AUTHENTIFICATION KOYAKO ===

// Variables globales pour la gestion de l'authentification
let formulaireActuel = 'connexion'
let validationEnCours = false

// Codes administrateur valides pour la démonstration
const CODES_ADMIN_VALIDES = [
  'KY-ADM-2024-001',
  'KY-ADM-2024-002', 
  'KY-ADM-2024-003',
  'KY-ADM-2024-DEMO'
]

// Comptes de démonstration
const COMPTES_DEMO = {
  'demo@koyako.cd': {
    motDePasse: 'demo123',
    type: 'membre',
    nom: 'Utilisateur Démo'
  },
  'admin@koyako.cd': {
    motDePasse: 'admin123',
    type: 'admin',
    nom: 'Administrateur Démo'
  }
}

// Initialisation au chargement de la page
document.addEventListener('DOMContentLoaded', () => {
  console.log('🔐 Initialisation de la page d\'authentification Koyako...')
  
  initialiserFormulaires()
  configurerValidation()
  verifierAuthentificationExistante()
  
  console.log('✅ Page d\'authentification initialisée!')
})

// Fonction d'initialisation des formulaires
function initialiserFormulaires() {
  const formulaireConnexion = document.getElementById('form-connexion')
  const formulaireInscription = document.getElementById('form-inscription')
  const selectTypeUtilisateur = document.getElementById('type-utilisateur')

  // Gérer le changement de type d'utilisateur
  if (selectTypeUtilisateur) {
    selectTypeUtilisateur.addEventListener('change', gererChangementTypeUtilisateur)
  }

  // Gérer la soumission du formulaire de connexion
  if (formulaireConnexion) {
    formulaireConnexion.addEventListener('submit', gererConnexion)
  }

  // Gérer la soumission du formulaire d'inscription
  if (formulaireInscription) {
    formulaireInscription.addEventListener('submit', gererInscription)
  }

  // Configurer la validation en temps réel
  configurerValidationTempsReel()
}

// Gérer le changement de type d'utilisateur
function gererChangementTypeUtilisateur(e) {
  const groupeEmail = document.getElementById('groupe-email')
  const groupeCodeAdmin = document.getElementById('groupe-code-admin')
  const champEmail = document.getElementById('email-connexion')
  const champCodeAdmin = document.getElementById('code-admin')

  if (e.target.value === 'admin') {
    // Mode administrateur
    groupeEmail.style.display = 'none'
    groupeCodeAdmin.style.display = 'block'
    champCodeAdmin.required = true
    champEmail.required = false
    
    // Animation de transition
    groupeCodeAdmin.style.opacity = '0'
    setTimeout(() => {
      groupeCodeAdmin.style.opacity = '1'
    }, 100)
  } else {
    // Mode membre
    groupeEmail.style.display = 'block'
    groupeCodeAdmin.style.display = 'none'
    champCodeAdmin.required = false
    champEmail.required = true
    
    // Animation de transition
    groupeEmail.style.opacity = '0'
    setTimeout(() => {
      groupeEmail.style.opacity = '1'
    }, 100)
  }
}

// Gérer la connexion
async function gererConnexion(e) {
  e.preventDefault()
  
  if (validationEnCours) return
  validationEnCours = true

  const boutonSoumettre = e.target.querySelector('button[type="submit"]')
  const texteOriginal = boutonSoumettre.querySelector('.btn-text').textContent
  
  // Afficher le loader
  afficherLoader(boutonSoumettre, true)

  try {
    const typeUtilisateur = document.getElementById('type-utilisateur').value
    const motDePasse = document.getElementById('mot-de-passe-connexion').value

    let identifiant = ''
    if (typeUtilisateur === 'admin') {
      identifiant = document.getElementById('code-admin').value
    } else {
      identifiant = document.getElementById('email-connexion').value
    }

    // Validation des champs
    if (!typeUtilisateur || !identifiant || !motDePasse) {
      throw new Error('Veuillez remplir tous les champs')
    }

    // Simulation d'un délai de connexion
    await new Promise(resolve => setTimeout(resolve, 1500))

    // Authentifier l'utilisateur
    const resultatAuth = await authentifierUtilisateur(typeUtilisateur, identifiant, motDePasse)
    
    if (resultatAuth.succes) {
      // Stocker les données utilisateur
      const donneesUtilisateur = {
        type: typeUtilisateur,
        identifiant: identifiant,
        nom: resultatAuth.nom,
        email: resultatAuth.email || identifiant,
        heureConnexion: new Date().toISOString(),
      }

      localStorage.setItem('koyako_utilisateur', JSON.stringify(donneesUtilisateur))

      // Gérer "Se souvenir de moi"
      const seSouvenir = document.getElementById('se-souvenir').checked
      if (seSouvenir) {
        localStorage.setItem('koyako_se_souvenir', 'true')
      }

      afficherMessage('Connexion réussie! Redirection...', 'succes')

      // Redirection selon le type d'utilisateur
      setTimeout(() => {
        if (typeUtilisateur === 'admin') {
          window.location.href = 'dashboard.html'
        } else {
          window.location.href = 'member-dashboard.html'
        }
      }, 1000)
    } else {
      throw new Error(resultatAuth.erreur || 'Identifiants incorrects')
    }
  } catch (erreur) {
    afficherMessage(erreur.message, 'erreur')
  } finally {
    afficherLoader(boutonSoumettre, false, texteOriginal)
    validationEnCours = false
  }
}

// Gérer l'inscription
async function gererInscription(e) {
  e.preventDefault()
  
  if (validationEnCours) return
  validationEnCours = true

  const boutonSoumettre = e.target.querySelector('button[type="submit"]')
  const texteOriginal = boutonSoumettre.querySelector('.btn-text').textContent
  
  afficherLoader(boutonSoumettre, true)

  try {
    const prenom = document.getElementById('prenom').value.trim()
    const nom = document.getElementById('nom').value.trim()
    const email = document.getElementById('email-inscription').value.trim()
    const telephone = document.getElementById('telephone').value.trim()
    const motDePasse = document.getElementById('mot-de-passe-inscription').value
    const confirmerMotDePasse = document.getElementById('confirmer-mot-de-passe').value
    const accepterConditions = document.getElementById('accepter-conditions').checked

    // Validation complète
    validerDonneesInscription({
      prenom, nom, email, telephone, motDePasse, confirmerMotDePasse, accepterConditions
    })

    // Simulation d'un délai d'inscription
    await new Promise(resolve => setTimeout(resolve, 2000))

    // Stocker les données utilisateur
    const donneesUtilisateur = {
      prenom: prenom,
      nom: nom,
      email: email,
      telephone: telephone,
      type: 'membre',
      heureInscription: new Date().toISOString(),
    }

    localStorage.setItem('koyako_utilisateur', JSON.stringify(donneesUtilisateur))

    afficherMessage('Inscription réussie! Redirection...', 'succes')

    setTimeout(() => {
      window.location.href = 'member-dashboard.html'
    }, 1500)
  } catch (erreur) {
    afficherMessage(erreur.message, 'erreur')
  } finally {
    afficherLoader(boutonSoumettre, false, texteOriginal)
    validationEnCours = false
  }
}

// Fonction pour changer d'onglet
function changerOnglet(nomOnglet) {
  // Masquer tous les formulaires
  document.querySelectorAll('.auth-form').forEach((formulaire) => {
    formulaire.classList.remove('active')
  })

  // Retirer la classe active de tous les onglets
  document.querySelectorAll('.tab-btn').forEach((bouton) => {
    bouton.classList.remove('active')
  })

  // Afficher le formulaire sélectionné et activer l'onglet
  if (nomOnglet === 'connexion') {
    document.getElementById('form-connexion').classList.add('active')
    document.querySelectorAll('.tab-btn')[0].classList.add('active')
    formulaireActuel = 'connexion'
  } else {
    document.getElementById('form-inscription').classList.add('active')
    document.querySelectorAll('.tab-btn')[1].classList.add('active')
    formulaireActuel = 'inscription'
  }

  // Réinitialiser les messages d'erreur
  supprimerMessages()
}

// Fonction d'authentification
async function authentifierUtilisateur(type, identifiant, motDePasse) {
  // Vérifier les comptes de démonstration
  if (COMPTES_DEMO[identifiant]) {
    const compte = COMPTES_DEMO[identifiant]
    if (compte.motDePasse === motDePasse && compte.type === type) {
      return {
        succes: true,
        nom: compte.nom,
        email: identifiant
      }
    }
  }

  if (type === 'admin') {
    // Vérifier les codes administrateur
    if (CODES_ADMIN_VALIDES.includes(identifiant) && motDePasse.length >= 6) {
      return {
        succes: true,
        nom: 'Administrateur Koyako',
        email: 'admin@koyako.cd'
      }
    }
  } else {
    // Pour les membres, vérifier le format email ou téléphone
    const formatEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    const formatTelephone = /^\+243\d{9}$/
    
    if ((formatEmail.test(identifiant) || formatTelephone.test(identifiant)) && motDePasse.length >= 6) {
      return {
        succes: true,
        nom: 'Membre Koyako',
        email: identifiant
      }
    }
  }

  return {
    succes: false,
    erreur: 'Identifiants incorrects'
  }
}

// Validation des données d'inscription
function validerDonneesInscription(donnees) {
  const { prenom, nom, email, telephone, motDePasse, confirmerMotDePasse, accepterConditions } = donnees

  if (!prenom || !nom || !email || !telephone || !motDePasse || !confirmerMotDePasse) {
    throw new Error('Veuillez remplir tous les champs')
  }

  if (!accepterConditions) {
    throw new Error('Vous devez accepter les conditions d\'utilisation')
  }

  // Validation de l'email
  const formatEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  if (!formatEmail.test(email)) {
    throw new Error('Format d\'email invalide')
  }

  // Validation du téléphone
  const formatTelephone = /^\+243\d{9}$/
  if (!formatTelephone.test(telephone)) {
    throw new Error('Format de téléphone invalide (+243XXXXXXXXX)')
  }

  // Validation du mot de passe
  if (motDePasse.length < 8) {
    throw new Error('Le mot de passe doit contenir au moins 8 caractères')
  }

  if (motDePasse !== confirmerMotDePasse) {
    throw new Error('Les mots de passe ne correspondent pas')
  }

  // Validation de la force du mot de passe
  const forceMotDePasse = calculerForceMotDePasse(motDePasse)
  if (forceMotDePasse < 3) {
    throw new Error('Le mot de passe est trop faible. Utilisez des majuscules, minuscules, chiffres et caractères spéciaux')
  }
}

// Calculer la force du mot de passe
function calculerForceMotDePasse(motDePasse) {
  let force = 0
  
  if (motDePasse.length >= 8) force++
  if (/[a-z]/.test(motDePasse)) force++
  if (/[A-Z]/.test(motDePasse)) force++
  if (/[0-9]/.test(motDePasse)) force++
  if (/[^A-Za-z0-9]/.test(motDePasse)) force++
  
  return force
}

// Configuration de la validation en temps réel
function configurerValidationTempsReel() {
  // Validation du mot de passe en temps réel
  const champMotDePasse = document.getElementById('mot-de-passe-inscription')
  if (champMotDePasse) {
    champMotDePasse.addEventListener('input', (e) => {
      const motDePasse = e.target.value
      const force = calculerForceMotDePasse(motDePasse)
      mettreAJourBarreForce(force, motDePasse.length)
    })
  }

  // Validation de la confirmation du mot de passe
  const champConfirmation = document.getElementById('confirmer-mot-de-passe')
  if (champConfirmation) {
    champConfirmation.addEventListener('input', (e) => {
      const motDePasse = document.getElementById('mot-de-passe-inscription').value
      const confirmation = e.target.value
      
      if (confirmation && motDePasse !== confirmation) {
        marquerChampInvalide(e.target, 'Les mots de passe ne correspondent pas')
      } else {
        marquerChampValide(e.target)
      }
    })
  }

  // Validation de l'email
  const champEmail = document.getElementById('email-inscription')
  if (champEmail) {
    champEmail.addEventListener('blur', (e) => {
      const email = e.target.value
      const formatEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
      
      if (email && !formatEmail.test(email)) {
        marquerChampInvalide(e.target, 'Format d\'email invalide')
      } else if (email) {
        marquerChampValide(e.target)
      }
    })
  }

  // Validation du téléphone
  const champTelephone = document.getElementById('telephone')
  if (champTelephone) {
    champTelephone.addEventListener('input', (e) => {
      let valeur = e.target.value.replace(/\D/g, '')
      if (valeur.startsWith('243')) {
        valeur = '+' + valeur
      } else if (valeur.startsWith('0')) {
        valeur = '+243' + valeur.substring(1)
      }
      e.target.value = valeur
    })

    champTelephone.addEventListener('blur', (e) => {
      const telephone = e.target.value
      const formatTelephone = /^\+243\d{9}$/
      
      if (telephone && !formatTelephone.test(telephone)) {
        marquerChampInvalide(e.target, 'Format: +243XXXXXXXXX')
      } else if (telephone) {
        marquerChampValide(e.target)
      }
    })
  }
}

// Mettre à jour la barre de force du mot de passe
function mettreAJourBarreForce(force, longueur) {
  const barreFill = document.querySelector('.strength-fill')
  const texteForce = document.querySelector('.strength-text')
  
  if (!barreFill || !texteForce) return

  const pourcentage = (force / 5) * 100
  barreFill.style.width = pourcentage + '%'

  let couleur, texte
  if (longueur === 0) {
    couleur = '#e5e7eb'
    texte = 'Utilisez au moins 8 caractères'
  } else if (force <= 2) {
    couleur = '#ef4444'
    texte = 'Mot de passe faible'
  } else if (force <= 3) {
    couleur = '#f59e0b'
    texte = 'Mot de passe moyen'
  } else if (force <= 4) {
    couleur = '#10b981'
    texte = 'Mot de passe fort'
  } else {
    couleur = '#059669'
    texte = 'Mot de passe très fort'
  }

  barreFill.style.background = couleur
  texteForce.textContent = texte
  texteForce.style.color = couleur
}

// Marquer un champ comme invalide
function marquerChampInvalide(champ, message) {
  const groupe = champ.closest('.form-group')
  groupe.classList.remove('valid')
  groupe.classList.add('invalid')
  
  // Ajouter ou mettre à jour le message d'erreur
  let messageErreur = groupe.querySelector('.error-message')
  if (!messageErreur) {
    messageErreur = document.createElement('small')
    messageErreur.className = 'error-message'
    messageErreur.style.color = '#ef4444'
    messageErreur.style.fontSize = '0.8rem'
    messageErreur.style.marginTop = '5px'
    messageErreur.style.display = 'block'
    groupe.appendChild(messageErreur)
  }
  messageErreur.textContent = message
}

// Marquer un champ comme valide
function marquerChampValide(champ) {
  const groupe = champ.closest('.form-group')
  groupe.classList.remove('invalid')
  groupe.classList.add('valid')
  
  // Supprimer le message d'erreur
  const messageErreur = groupe.querySelector('.error-message')
  if (messageErreur) {
    messageErreur.remove()
  }
}

// Afficher/masquer le loader sur un bouton
function afficherLoader(bouton, afficher, texteOriginal = '') {
  const texte = bouton.querySelector('.btn-text')
  const loader = bouton.querySelector('.btn-loader')
  
  if (afficher) {
    texte.style.display = 'none'
    loader.style.display = 'inline'
    bouton.disabled = true
  } else {
    texte.style.display = 'inline'
    loader.style.display = 'none'
    bouton.disabled = false
    if (texteOriginal) {
      texte.textContent = texteOriginal
    }
  }
}

// Fonction pour afficher des messages
function afficherMessage(message, type) {
  // Supprimer les anciens messages
  supprimerMessages()

  // Créer le nouveau message
  const divMessage = document.createElement('div')
  divMessage.className = `message-auth message-${type}`
  divMessage.textContent = message

  // Insérer le message au début du formulaire actif
  const formulaireActif = document.querySelector('.auth-form.active')
  formulaireActif.insertBefore(divMessage, formulaireActif.firstChild)

  // Supprimer le message après 5 secondes
  setTimeout(() => {
    if (divMessage.parentNode) {
      divMessage.remove()
    }
  }, 5000)
}

// Supprimer tous les messages
function supprimerMessages() {
  document.querySelectorAll('.message-auth').forEach(message => {
    message.remove()
  })
}

// Configuration de la validation générale
function configurerValidation() {
  // Validation en temps réel pour tous les champs requis
  document.querySelectorAll('input[required], select[required]').forEach(champ => {
    champ.addEventListener('blur', () => {
      if (!champ.value.trim()) {
        marquerChampInvalide(champ, 'Ce champ est requis')
      } else {
        marquerChampValide(champ)
      }
    })
  })
}

// Vérifier si l'utilisateur est déjà connecté
function verifierAuthentificationExistante() {
  const utilisateur = localStorage.getItem('koyako_utilisateur')
  const seSouvenir = localStorage.getItem('koyako_se_souvenir')
  
  if (utilisateur && seSouvenir === 'true') {
    const donneesUtilisateur = JSON.parse(utilisateur)
    
    // Pré-remplir les champs si l'utilisateur a choisi de se souvenir
    if (donneesUtilisateur.type === 'admin') {
      document.getElementById('type-utilisateur').value = 'admin'
      document.getElementById('code-admin').value = donneesUtilisateur.identifiant
      gererChangementTypeUtilisateur({ target: { value: 'admin' } })
    } else {
      document.getElementById('type-utilisateur').value = 'membre'
      document.getElementById('email-connexion').value = donneesUtilisateur.identifiant
    }
    
    document.getElementById('se-souvenir').checked = true
    
    afficherMessage('Connexion automatique disponible', 'info')
  }
}

// Gestion des raccourcis clavier
document.addEventListener('keydown', (e) => {
  // Entrée pour soumettre le formulaire actif
  if (e.key === 'Enter' && e.ctrlKey) {
    const formulaireActif = document.querySelector('.auth-form.active')
    if (formulaireActif) {
      const boutonSoumettre = formulaireActif.querySelector('button[type="submit"]')
      if (boutonSoumettre && !boutonSoumettre.disabled) {
        boutonSoumettre.click()
      }
    }
  }
  
  // Échap pour effacer les messages
  if (e.key === 'Escape') {
    supprimerMessages()
  }
})

// Export des fonctions pour utilisation externe
window.KoyakoAuth = {
  changerOnglet,
  afficherMessage,
  verifierAuthentificationExistante
}

console.log('🔐 Script d\'authentification Koyako chargé avec succès!')
