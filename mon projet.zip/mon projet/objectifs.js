// === SCRIPT POUR LA PAGE OBJECTIFS ===

document.addEventListener('DOMContentLoaded', () => {
  console.log('🎯 Chargement de la page objectifs Koyako...')
  
  initialiserNavigation()
  initialiserAnimationsObjectifs()
  initialiserInteractionsCartes()
  initialiserCompteurs()
  
  console.log('✅ Page objectifs chargée avec succès!')
})

// Initialiser la navigation
function initialiserNavigation() {
  const hamburger = document.querySelector('.hamburger')
  const navMenu = document.querySelector('.nav-menu')

  if (hamburger && navMenu) {
    hamburger.addEventListener('click', () => {
      hamburger.classList.toggle('active')
      navMenu.classList.toggle('active')
    })

    document.querySelectorAll('.nav-menu a').forEach(lien => {
      lien.addEventListener('click', () => {
        hamburger.classList.remove('active')
        navMenu.classList.remove('active')
      })
    })
  }

  // Effet de défilement sur la navbar
  window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar')
    if (window.scrollY > 50) {
      navbar.style.background = 'rgba(255, 255, 255, 0.98)'
      navbar.style.boxShadow = '0 2px 20px rgba(0,0,0,0.1)'
    } else {
      navbar.style.background = 'rgba(255, 255, 255, 0.95)'
      navbar.style.boxShadow = 'none'
    }
  })
}

// Initialiser les animations des objectifs
function initialiserAnimationsObjectifs() {
  const observateur = new IntersectionObserver((entrees) => {
    entrees.forEach(entree => {
      if (entree.isIntersecting) {
        entree.target.style.opacity = '1'
        entree.target.style.transform = 'translateY(0)'
      }
    })
  }, {
    threshold: 0.1
  })

  // Animer les cartes d'objectifs
  document.querySelectorAll('.objectif-card').forEach((carte, index) => {
    carte.style.opacity = '0'
    carte.style.transform = 'translateY(50px)'
    carte.style.transition = `all 0.6s ease ${index * 0.1}s`
    observateur.observe(carte)
  })

  // Animer les cartes de mission
  document.querySelectorAll('.mission-card').forEach((carte, index) => {
    carte.style.opacity = '0'
    carte.style.transform = 'translateY(30px)'
    carte.style.transition = `all 0.6s ease ${index * 0.2}s`
    observateur.observe(carte)
  })

  // Animer les valeurs
  document.querySelectorAll('.valeur-item').forEach((item, index) => {
    item.style.opacity = '0'
    item.style.transform = 'scale(0.9)'
    item.style.transition = `all 0.5s ease ${index * 0.1}s`
    observateur.observe(item)
  })
}

// Initialiser les interactions des cartes
function initialiserInteractionsCartes() {
  const cartesObjectifs = document.querySelectorAll('.objectif-card')
  
  cartesObjectifs.forEach(carte => {
    carte.addEventListener('mouseenter', () => {
      // Ajouter un effet de pulsation à l'icône
      const icone = carte.querySelector('.objectif-icon')
      icone.style.transform = 'scale(1.1)'
      icone.style.transition = 'transform 0.3s ease'
    })

    carte.addEventListener('mouseleave', () => {
      const icone = carte.querySelector('.objectif-icon')
      icone.style.transform = 'scale(1)'
    })

    // Effet de clic pour révéler plus de détails
    carte.addEventListener('click', () => {
      const details = carte.querySelector('.objectif-details')
      const autresCartes = document.querySelectorAll('.objectif-card')
      
      // Fermer les autres cartes
      autresCartes.forEach(autreCarte => {
        if (autreCarte !== carte) {
          const autresDetails = autreCarte.querySelector('.objectif-details')
          autresDetails.style.opacity = '0'
          autresDetails.style.maxHeight = '0'
          autreCarte.classList.remove('active')
        }
      })

      // Basculer la carte actuelle
      if (carte.classList.contains('active')) {
        details.style.opacity = '0'
        details.style.maxHeight = '0'
        carte.classList.remove('active')
      } else {
        details.style.opacity = '1'
        details.style.maxHeight = '200px'
        carte.classList.add('active')
      }
    })
  })

  // Effet hover pour les cartes de mission
  document.querySelectorAll('.mission-card').forEach(carte => {
    carte.addEventListener('mouseenter', () => {
      const icone = carte.querySelector('.mission-icon')
      icone.style.transform = 'rotate(360deg) scale(1.1)'
      icone.style.transition = 'transform 0.5s ease'
    })

    carte.addEventListener('mouseleave', () => {
      const icone = carte.querySelector('.mission-icon')
      icone.style.transform = 'rotate(0deg) scale(1)'
    })
  })

  // Effet hover pour les valeurs
  document.querySelectorAll('.valeur-item').forEach(item => {
    item.addEventListener('mouseenter', () => {
      const icone = item.querySelector('.valeur-icon')
      icone.style.transform = 'scale(1.2)'
      icone.style.transition = 'transform 0.3s ease'
    })

    item.addEventListener('mouseleave', () => {
      const icone = item.querySelector('.valeur-icon')
      icone.style.transform = 'scale(1)'
    })
  })
}

// Initialiser les compteurs animés
function initialiserCompteurs() {
  const observateurCompteurs = new IntersectionObserver((entrees) => {
    entrees.forEach(entree => {
      if (entree.isIntersecting) {
        const compteur = entree.target
        const valeurCible = parseInt(compteur.textContent.replace(/[^\d]/g, ''))
        animerCompteur(compteur, valeurCible)
        observateurCompteurs.unobserve(compteur)
      }
    })
  })

  document.querySelectorAll('.stat h4').forEach(compteur => {
    observateurCompteurs.observe(compteur)
  })
}

// Fonction pour animer un compteur
function animerCompteur(element, valeurCible, duree = 2000) {
  let valeurActuelle = 0
  const increment = valeurCible / (duree / 16)
  const texteOriginal = element.textContent
  const suffixe = texteOriginal.replace(/[\d,]/g, '')

  const timer = setInterval(() => {
    valeurActuelle += increment
    const valeurAffichee = Math.floor(valeurActuelle)
    
    if (valeurAffichee >= 1000) {
      element.textContent = (valeurAffichee / 1000).toFixed(0) + 'K' + suffixe.replace(/[\d,K]/g, '')
    } else {
      element.textContent = valeurAffichee.toLocaleString() + suffixe.replace(/[\d,]/g, '')
    }

    if (valeurActuelle >= valeurCible) {
      element.textContent = texteOriginal
      clearInterval(timer)
    }
  }, 16)
}

// Gestion du redimensionnement
window.addEventListener('resize', () => {
  const hamburger = document.querySelector('.hamburger')
  const navMenu = document.querySelector('.nav-menu')
  
  if (window.innerWidth > 768) {
    hamburger?.classList.remove('active')
    navMenu?.classList.remove('active')
  }
})

// Effet de parallaxe léger pour la section hero
window.addEventListener('scroll', () => {
  const scrolled = window.pageYOffset
  const hero = document.querySelector('.hero')
  const speed = scrolled * 0.1

  if (hero) {
    hero.style.transform = `translateY(${speed}px)`
  }
})

// Fonction pour révéler progressivement les éléments
function revelerElement(element, delai = 0) {
  setTimeout(() => {
    element.style.opacity = '1'
    element.style.transform = 'translateY(0)'
  }, delai)
}

// Ajouter des styles CSS dynamiques pour les états actifs
const style = document.createElement('style')
style.textContent = `
  .objectif-card.active {
    border-color: #2563eb;
    box-shadow: 0 20px 40px rgba(37, 99, 235, 0.3);
  }
  
  .objectif-card.active .objectif-icon {
    background: linear-gradient(135deg, #2563eb 0%, #1d4ed8 100%);
    color: white;
  }
`
document.head.appendChild(style)

console.log('🎯 Script objectifs Koyako chargé!')
