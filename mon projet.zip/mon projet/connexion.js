// === SCRIPT DE CONNEXION ET INSCRIPTION KOYAKO ===

// Variables globales
let modeConnexion = true
let utilisateurs = []
let codesAdmin = []

// Initialisation au chargement de la page
document.addEventListener('DOMContentLoaded', () => {
  console.log('🔷 Initialisation de la page de connexion Koyako...')
  
  initialiserPage()
  chargerUtilisateursSimules()
  configurerGestionnaireEvenements()
  
  console.log('✅ Page de connexion initialisée avec succès!')
})

// Initialiser la page
function initialiserPage() {
  // Vérifier si l'utilisateur est déjà connecté
  const utilisateurConnecte = localStorage.getItem('koyako_utilisateur')
  if (utilisateurConnecte) {
    const utilisateur = JSON.parse(utilisateurConnecte)
    redirigerVersDashboard(utilisateur.type)
    return
  }

  // Afficher le mode connexion par défaut
  afficherModeConnexion()
}

// Charger des utilisateurs simulés pour la démonstration
function chargerUtilisateursSimules() {
  utilisateurs = [
    {
      id: 1,
      nom: 'Mukendi',
      prenom: 'Jean',
      email: 'jean.mukendi@email.com',
      motDePasse: 'password123',
      telephone: '+243 123 456 789',
      type: 'gerant',
      dateInscription: '2024-01-15'
    },
    {
      id: 2,
      nom: 'Kabila',
      prenom: 'Marie',
      email: 'marie.kabila@email.com',
      motDePasse: 'password123',
      telephone: '+243 987 654 321',
      type: 'membre',
      dateInscription: '2024-02-01'
    },
    {
      id: 3,
      nom: 'Tshisekedi',
      prenom: 'Paul',
      email: 'paul.tshisekedi@email.com',
      motDePasse: 'password123',
      telephone: '+243 555 123 456',
      type: 'gerant',
      dateInscription: '2024-01-20'
    }
  ]
}

// Configurer les gestionnaires d'événements
function configurerGestionnaireEvenements() {
  // Gestionnaire pour le changement de mode
  const boutonChangerMode = document.getElementById('changer-mode')
  if (boutonChangerMode) {
    boutonChangerMode.addEventListener('click', changerMode)
  }

  // Gestionnaire pour le formulaire unifié
  const formUnifie = document.getElementById('formulaire-unifie')
  if (formUnifie) {
    formUnifie.addEventListener('submit', traiterFormulaire)
  }

  // Gestionnaire pour la validation du code admin
  const champCodeAdmin = document.getElementById('code-admin')
  if (champCodeAdmin) {
    champCodeAdmin.addEventListener('input', validerCodeAdmin)
  }

  // Gestionnaire pour le changement de type d'utilisateur
  const selectType = document.getElementById('type-utilisateur')
  if (selectType) {
    selectType.addEventListener('change', gererChangementType)
  }
}

// Changer entre les modes connexion et inscription
function changerMode() {
  modeConnexion = !modeConnexion
  
  if (modeConnexion) {
    afficherModeConnexion()
  } else {
    afficherModeInscription()
  }
}

// Afficher le mode connexion
function afficherModeConnexion() {
  const titre = document.getElementById('titre-page')
  const sousTitre = document.getElementById('sous-titre-page')
  const boutonMode = document.getElementById('changer-mode')
  const champsInscription = document.getElementById('champs-inscription')
  const optionsConnexion = document.getElementById('options-connexion')
  const btnText = document.getElementById('btn-text')
  const btnIcon = document.getElementById('btn-icon')
  const boutonIcon = boutonMode.querySelector('.btn-icon')
  const boutonText = boutonMode.querySelector('.btn-text')

  if (titre) titre.textContent = '🔷 Koyako'
  if (sousTitre) sousTitre.textContent = 'Connectez-vous à votre espace de cotisations'
  if (boutonIcon) boutonIcon.textContent = '📝'
  if (boutonText) boutonText.textContent = 'Créer un compte'
  if (btnText) btnText.textContent = 'Se connecter'
  if (btnIcon) btnIcon.textContent = '🔐'
  
  if (champsInscription) champsInscription.style.display = 'none'
  if (optionsConnexion) optionsConnexion.style.display = 'flex'
  
  // Réinitialiser les champs d'inscription
  reinitialiserChampsInscription()
}

// Afficher le mode inscription
function afficherModeInscription() {
  const titre = document.getElementById('titre-page')
  const sousTitre = document.getElementById('sous-titre-page')
  const boutonMode = document.getElementById('changer-mode')
  const champsInscription = document.getElementById('champs-inscription')
  const optionsConnexion = document.getElementById('options-connexion')
  const btnText = document.getElementById('btn-text')
  const btnIcon = document.getElementById('btn-icon')
  const boutonIcon = boutonMode.querySelector('.btn-icon')
  const boutonText = boutonMode.querySelector('.btn-text')

  if (titre) titre.textContent = '🔷 Koyako'
  if (sousTitre) sousTitre.textContent = 'Créez votre compte de cotisations'
  if (boutonIcon) boutonIcon.textContent = '🔐'
  if (boutonText) boutonText.textContent = 'Déjà un compte ?'
  if (btnText) btnText.textContent = 'Créer mon compte'
  if (btnIcon) btnIcon.textContent = '📝'
  
  if (champsInscription) champsInscription.style.display = 'block'
  if (optionsConnexion) optionsConnexion.style.display = 'none'
}

// Réinitialiser les champs d'inscription
function reinitialiserChampsInscription() {
  const champs = ['nom-inscription', 'prenom-inscription', 'telephone-inscription', 'type-utilisateur', 'code-admin', 'confirmer-mot-de-passe', 'accepter-conditions']
  champs.forEach(id => {
    const champ = document.getElementById(id)
    if (champ) {
      if (champ.type === 'checkbox') {
        champ.checked = false
      } else {
        champ.value = ''
      }
    }
  })
  
  // Cacher le champ code admin
  const champCodeAdmin = document.getElementById('champ-code-admin')
  if (champCodeAdmin) {
    champCodeAdmin.style.display = 'none'
  }
}

// Traiter le formulaire unifié
function traiterFormulaire(e) {
  e.preventDefault()
  
  if (modeConnexion) {
    seConnecter()
  } else {
    sinscrire()
  }
}

// Se connecter
function seConnecter() {
  const email = document.getElementById('email').value
  const motDePasse = document.getElementById('mot-de-passe').value

  // Validation des champs
  if (!email || !motDePasse) {
    afficherNotification('Veuillez remplir tous les champs', 'erreur')
    return
  }

  // Rechercher l'utilisateur
  const utilisateur = utilisateurs.find(u => 
    u.email.toLowerCase() === email.toLowerCase() && 
    u.motDePasse === motDePasse
  )

  if (!utilisateur) {
    afficherNotification('Email ou mot de passe incorrect', 'erreur')
    return
  }

  // Sauvegarder les données de l'utilisateur
  localStorage.setItem('koyako_utilisateur', JSON.stringify(utilisateur))
  
  afficherNotification('Connexion réussie ! Redirection...', 'succes')
  
  // Rediriger vers le bon dashboard
  setTimeout(() => {
    redirigerVersDashboard(utilisateur.type)
  }, 1500)
}

// S'inscrire
function sinscrire() {
  const nom = document.getElementById('nom-inscription').value
  const prenom = document.getElementById('prenom-inscription').value
  const email = document.getElementById('email').value
  const telephone = document.getElementById('telephone-inscription').value
  const motDePasse = document.getElementById('mot-de-passe').value
  const confirmerMotDePasse = document.getElementById('confirmer-mot-de-passe').value
  const typeUtilisateur = document.getElementById('type-utilisateur').value
  const codeAdmin = document.getElementById('code-admin').value
  const accepterConditions = document.getElementById('accepter-conditions').checked

  // Validation des champs
  if (!nom || !prenom || !email || !telephone || !motDePasse || !confirmerMotDePasse || !typeUtilisateur) {
    afficherNotification('Veuillez remplir tous les champs obligatoires', 'erreur')
    return
  }

  if (!accepterConditions) {
    afficherNotification('Vous devez accepter les conditions d\'utilisation', 'erreur')
    return
  }

  if (motDePasse !== confirmerMotDePasse) {
    afficherNotification('Les mots de passe ne correspondent pas', 'erreur')
    return
  }

  if (motDePasse.length < 6) {
    afficherNotification('Le mot de passe doit contenir au moins 6 caractères', 'erreur')
    return
  }

  // Validation du code admin si c'est un gérant
  if (typeUtilisateur === 'gerant') {
    if (!codeAdmin) {
      afficherNotification('Le code administrateur est requis pour les gérants', 'erreur')
      return
    }
    
    if (!validerCodeAdmin(codeAdmin)) {
      afficherNotification('Code administrateur invalide', 'erreur')
      return
    }
  }

  // Vérifier si l'email existe déjà
  const emailExiste = utilisateurs.some(u => u.email.toLowerCase() === email.toLowerCase())
  if (emailExiste) {
    afficherNotification('Cet email est déjà utilisé', 'erreur')
    return
  }

  // Créer le nouvel utilisateur
  const nouvelUtilisateur = {
    id: utilisateurs.length + 1,
    nom: nom,
    prenom: prenom,
    email: email,
    telephone: telephone,
    motDePasse: motDePasse,
    type: typeUtilisateur,
    dateInscription: new Date().toISOString().split('T')[0]
  }

  // Ajouter à la liste des utilisateurs
  utilisateurs.push(nouvelUtilisateur)

  // Sauvegarder les données de l'utilisateur
  localStorage.setItem('koyako_utilisateur', JSON.stringify(nouvelUtilisateur))
  
  // GÉNÉRER LE CODE DE CONFIRMATION POUR LES GÉRANTS
  if (typeUtilisateur === 'gerant') {
    // Générer un code unique pour ce gérant
    const codeConfirmation = genererCodeConfirmation();
    
    // Sauvegarder le code de confirmation
    localStorage.setItem('code-confirmation-gérant', codeConfirmation);
    
    // Afficher le code de confirmation (comme Facebook)
    afficherCodeConfirmation(codeConfirmation, nouvelUtilisateur);
    
    // Rediriger vers la page de création de groupe avec le code
    setTimeout(() => {
      window.location.href = `dashboard-gerant.html?code=${encodeURIComponent(codeConfirmation)}&nouveau=true`;
    }, 3000);
    
  } else {
    // Pour les membres, redirection directe
    afficherNotification('Inscription réussie ! Redirection...', 'succes')
    setTimeout(() => {
      redirigerVersDashboard(typeUtilisateur);
    }, 1500);
  }
}

// Générer un code de confirmation unique
function genererCodeConfirmation() {
  const prefixe = 'KY-CONF'
  const annee = new Date().getFullYear()
  const aleatoire = Math.floor(Math.random() * 10000).toString().padStart(4, '0')
  return `${prefixe}-${annee}-${aleatoire}`
}

// Afficher le code de confirmation (comme Facebook)
function afficherCodeConfirmation(code, utilisateur) {
  // Créer une modal pour afficher le code
  const modal = document.createElement('div')
  modal.className = 'modal-confirmation'
  modal.innerHTML = `
    <div class="modal-content">
      <div class="modal-header">
        <h2>🎉 Inscription Réussie !</h2>
        <p>Bienvenue ${utilisateur.prenom} ${utilisateur.nom} !</p>
      </div>
      
      <div class="modal-body">
        <div class="code-section">
          <h3>🔑 Votre Code de Confirmation</h3>
          <div class="code-display">
            <span class="code-text">${code}</span>
            <button class="btn-copy" onclick="copierCode('${code}')">📋 Copier</button>
          </div>
          <p class="code-info">
            <strong>Important :</strong> Ce code vous permettra de créer vos groupes et d'accéder à votre espace gérant.
            Gardez-le précieusement !
          </p>
        </div>
        
        <div class="next-steps">
          <h3>📋 Prochaines Étapes :</h3>
          <ol>
            <li>Copiez votre code de confirmation</li>
            <li>Vous serez redirigé vers votre espace gérant</li>
            <li>Créez votre premier groupe</li>
            <li>Invitez vos membres</li>
          </ol>
        </div>
      </div>
      
      <div class="modal-footer">
        <button class="btn-primary" onclick="continuerVersDashboard()">
          Continuer vers mon espace gérant
        </button>
      </div>
    </div>
  `
  
  // Styles pour la modal
  modal.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.8);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10000;
    animation: fadeIn 0.3s ease;
  `
  
  document.body.appendChild(modal)
}

// Fonction pour copier le code
function copierCode(code) {
  navigator.clipboard.writeText(code).then(() => {
    afficherNotification('Code copié dans le presse-papiers !', 'succes')
  }).catch(() => {
    afficherNotification('Erreur lors de la copie', 'erreur')
  })
}

// Fonction pour continuer vers le dashboard
function continuerVersDashboard() {
  const code = localStorage.getItem('code-confirmation-gérant')
  if (code) {
    window.location.href = `dashboard-gerant.html?code=${encodeURIComponent(code)}&nouveau=true`
  }
}

// Rediriger vers le bon dashboard selon le type d'utilisateur
function redirigerVersDashboard(typeUtilisateur) {
  if (typeUtilisateur === 'gerant') {
    window.location.href = 'dashboard-gerant.html'
  } else if (typeUtilisateur === 'membre') {
    window.location.href = 'dashboard-membre.html'
  } else {
    // Fallback vers le dashboard principal qui redirigera automatiquement
    window.location.href = 'dashboard.html'
  }
}

// Valider le code administrateur
function validerCodeAdmin(code) {
  // Codes administrateur valides (en production, cela viendrait d'une base de données)
  const codesValides = [
    'ADMIN-2024-001',
    'ADMIN-2024-002',
    'ADMIN-2024-003',
    'KY-ADM-2024-001',
    'KY-ADM-2024-002'
  ]
  
  return codesValides.includes(code.toUpperCase())
}

// Gérer le changement de type d'utilisateur
function gererChangementType() {
  const typeUtilisateur = document.getElementById('type-utilisateur').value
  const champCodeAdmin = document.getElementById('champ-code-admin')
  
  if (typeUtilisateur === 'gerant') {
    if (champCodeAdmin) {
      champCodeAdmin.style.display = 'block'
      document.getElementById('code-admin').required = true
    }
  } else {
    if (champCodeAdmin) {
      champCodeAdmin.style.display = 'none'
      document.getElementById('code-admin').required = false
      document.getElementById('code-admin').value = ''
    }
  }
}p

// Afficher une notification
function afficherNotification(message, type = 'info') {
  // Supprimer les notifications existantes
  const notificationsExistantes = document.querySelectorAll('.notification')
  notificationsExistantes.forEach(notif => notif.remove())

  // Créer l'élément de notification
  const notification = document.createElement('div')
  notification.className = `notification ${type}`
  notification.innerHTML = `
    <div class="notification-content">
      <span class="notification-message">${message}</san>
      <button class="notification-close" onclick="this.parentElement.parentElement.remove()">×</button>
    </div>
  `

  // Ajouter au DOM
  document.body.appendChild(notification)

  // Supprimer automatiquement après 5 secondes
  setTimeout(() => {
    if (notification.parentElement) {
      notification.remove()
    }
  }, 5000)
}

// Validation en temps réel du code admin
function validerCodeAdmin() {
  const codeAdmin = 123 //document.getElementById('code-admin').value
  const boutonInscription = document.querySelector('#formulaire-inscription button[type="submit"]')
  
  if (codeAdmin) {
    const estValide = validerCodeAdmin(codeAdmin)
    const champCodeAdmin = document.getElementById('code-admin')
    
    if (estValide) {
      champCodeAdmin.style.borderColor = '#10B981'
      champCodeAdmin.style.backgroundColor = 'rgba(16, 185, 129, 0.1)'
      if (boutonInscription) boutonInscription.disabled = false
    } else {
      champCodeAdmin.style.borderColor = '#EF4444'
      champCodeAdmin.style.backgroundColor = 'rgba(239, 68, 68, 0.1)'
      if (boutonInscription) boutonInscription.disabled = true
    }
  } else {
    const champCodeAdmin = document.getElementById('code-admin')
    champCodeAdmin.style.borderColor = '#E5E7EB'
    champCodeAdmin.style.backgroundColor = 'white'
    if (boutonInscription) boutonInscription.disabled = false
  }
}

// Export des fonctions pour utilisation globale
window.changerMode = changerMode
window.traiterFormulaire = traiterFormulaire
window.validerCodeAdmin = validerCodeAdmin
window.gererChangementType = gererChangementType
window.copierCode = copierCode
window.continuerVersDashboard = continuerVersDashboard

console.log('🔷 Script de connexion Koyako chargé avec succès!')
