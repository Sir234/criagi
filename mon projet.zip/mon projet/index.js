// === SCRIPT POUR LA PAGE D'ACCUEIL KOYAKO ===

// Fonction pour faire défiler vers une section spécifique
function scrollToSection(sectionId) {
  const element = document.getElementById(sectionId)
  if (element) {
    element.scrollIntoView({
      behavior: "smooth",
      block: "start",
    })
  }
}

// Gestion du menu mobile
function initialiserMenuMobile() {
  const hamburger = document.querySelector(".hamburger")
  const navMenu = document.querySelector(".nav-menu")

  if (hamburger && navMenu) {
    // Basculer le menu mobile
    hamburger.addEventListener("click", () => {
      hamburger.classList.toggle("active")
      navMenu.classList.toggle("active")
    })

    // Fermer le menu mobile lors du clic sur un lien
    document.querySelectorAll(".nav-menu a").forEach((lien) =>
      lien.addEventListener("click", () => {
        hamburger.classList.remove("active")
        navMenu.classList.remove("active")
      }),
    )
  }
}

// Défilement fluide pour tous les liens d'ancrage
function initialiserDefilementFluide() {
  document.querySelectorAll('a[href^="#"]').forEach((ancre) => {
    ancre.addEventListener("click", function (e) {
      e.preventDefault()
      const cible = document.querySelector(this.getAttribute("href"))
      if (cible) {
        cible.scrollIntoView({
          behavior: "smooth",
          block: "start",
        })
      }
    })
  })
}

// Changement de style de la navbar au défilement
function gererNavbarDefilement() {
  const navbar = document.querySelector(".navbar")
  
  window.addEventListener("scroll", () => {
    if (window.scrollY > 50) {
      navbar.style.background = "rgba(255, 255, 255, 0.98)"
      navbar.style.boxShadow = "0 2px 20px rgba(0,0,0,0.1)"
    } else {
      navbar.style.background = "rgba(255, 255, 255, 0.95)"
      navbar.style.boxShadow = "none"
    }
  })
}

// Animation simple au défilement (AOS - Animate On Scroll)
function initialiserAnimationsDefilement() {
  function animerAuDefilement() {
    const elements = document.querySelectorAll("[data-aos]")

    elements.forEach((element) => {
      const elementTop = element.getBoundingClientRect().top
      const elementVisible = 150

      if (elementTop < window.innerHeight - elementVisible) {
        element.classList.add("aos-animate")
      }
    })
  }

  // Déclencher les animations au défilement et au chargement
  window.addEventListener("scroll", animerAuDefilement)
  window.addEventListener("load", animerAuDefilement)
  
  // Déclencher immédiatement pour les éléments déjà visibles
  animerAuDefilement()
}

// Effet parallaxe pour la section hero
function initialiserEffetParallaxe() {
  window.addEventListener("scroll", () => {
    const scrolled = window.pageYOffset
    const parallax = document.querySelector(".hero")
    const speed = scrolled * 0.2

    if (parallax) {
      parallax.style.transform = `translateY(${speed}px)`
    }
  })
}

// Compteur animé pour les statistiques (si nécessaire)
function animerCompteur(element, cible, duree = 2000) {
  let debut = 0
  const increment = cible / (duree / 16)

  const timer = setInterval(() => {
    debut += increment
    element.textContent = Math.floor(debut)

    if (debut >= cible) {
      element.textContent = cible
      clearInterval(timer)
    }
  }, 16)
}

// Vérifier si l'utilisateur est déjà connecté
function verifierAuthentification() {
  const utilisateur = localStorage.getItem("koyako_utilisateur")
  if (utilisateur) {
    const donneesUtilisateur = JSON.parse(utilisateur)
    
    // Afficher un message de bienvenue discret
    console.log(`Utilisateur connecté: ${donneesUtilisateur.nom || donneesUtilisateur.type}`)
    
    // Optionnel: modifier le bouton de connexion
    const boutonConnexion = document.querySelector(".cta-button")
    if (boutonConnexion) {
      boutonConnexion.textContent = "Mon Espace"
      boutonConnexion.href = "dashboard.html"
    }
  }
}

// Gestion des erreurs d'images
function gererErreursImages() {
  const images = document.querySelectorAll("img")
  images.forEach((img) => {
    img.addEventListener("error", function () {
      // Remplacer par une image par défaut en cas d'erreur
      this.src = "/placeholder.svg?height=300&width=400&text=Image+Koyako"
      this.alt = "Image Koyako"
    })
  })
}

// Optimisation des performances - Lazy loading pour les images
function initialiserLazyLoading() {
  if ("IntersectionObserver" in window) {
    const imageObserver = new IntersectionObserver((entries, observer) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const img = entry.target
          img.src = img.dataset.src || img.src
          img.classList.remove("lazy")
          imageObserver.unobserve(img)
        }
      })
    })

    const lazyImages = document.querySelectorAll("img[data-src]")
    lazyImages.forEach((img) => imageObserver.observe(img))
  }
}

// Fonction pour afficher des notifications toast
function afficherNotification(message, type = "info") {
  const notification = document.createElement("div")
  notification.className = `notification toast-${type}`
  notification.textContent = message

  // Styles pour la notification
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    padding: 15px 20px;
    border-radius: 8px;
    color: white;
    font-weight: 500;
    z-index: 9999;
    transform: translateX(100%);
    transition: transform 0.3s ease;
    max-width: 300px;
  `

  // Couleurs selon le type
  switch (type) {
    case "success":
      notification.style.background = "#10b981"
      break
    case "error":
      notification.style.background = "#ef4444"
      break
    case "warning":
      notification.style.background = "#f59e0b"
      break
    default:
      notification.style.background = "#2563eb"
  }

  document.body.appendChild(notification)

  // Animation d'entrée
  setTimeout(() => {
    notification.style.transform = "translateX(0)"
  }, 100)

  // Suppression automatique
  setTimeout(() => {
    notification.style.transform = "translateX(100%)"
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove()
      }
    }, 300)
  }, 4000)
}

// Fonction d'initialisation principale
function initialiserPageAccueil() {
  console.log("🔷 Initialisation de la page d'accueil Koyako...")

  // Initialiser tous les composants
  initialiserMenuMobile()
  initialiserDefilementFluide()
  gererNavbarDefilement()
  initialiserAnimationsDefilement()
  initialiserEffetParallaxe()
  verifierAuthentification()
  gererErreursImages()
  initialiserLazyLoading()

  console.log("Page d'accueil Koyako initialisée avec succès!")
}

// Démarrage de l'application au chargement du DOM
document.addEventListener("DOMContentLoaded", initialiserPageAccueil)

// Gestion du redimensionnement de la fenêtre
window.addEventListener("resize", () => {
  // Fermer le menu mobile si la fenêtre est redimensionnée
  const hamburger = document.querySelector(".hamburger")
  const navMenu = document.querySelector(".nav-menu")
  
  if (window.innerWidth > 768) {
    hamburger?.classList.remove("active")
    navMenu?.classList.remove("active")
  }
})

// Gestion de la visibilité de la page (Performance)
document.addEventListener("visibilitychange", () => {
  if (document.hidden) {
    console.log("Page Koyako masquée")
  } else {
    console.log("Page Koyako visible")
  }
})

// Export des fonctions pour utilisation externe si nécessaire
window.KoyakoAccueil = {
  scrollToSection,
  afficherNotification,
  verifierAuthentification,
}
