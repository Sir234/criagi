// === SCRIPT POUR LA PAGE D'ACCUEIL ===

document.addEventListener('DOMContentLoaded', () => {
  console.log('🏠 Chargement de la page d\'accueil Koyako...')
  
  initialiserNavigation()
  initialiserAnimations()
  verifierUtilisateurConnecte()
  
  console.log('✅ Page d\'accueil chargée avec succès!')
})

// Initialiser la navigation
function initialiserNavigation() {
  const hamburger = document.querySelector('.hamburger')
  const navMenu = document.querySelector('.nav-menu')

  if (hamburger && navMenu) {
    hamburger.addEventListener('click', () => {
      hamburger.classList.toggle('active')
      navMenu.classList.toggle('active')
    })

    // Fermer le menu mobile lors du clic sur un lien
    document.querySelectorAll('.nav-menu a').forEach(lien => {
      lien.addEventListener('click', () => {
        hamburger.classList.remove('active')
        navMenu.classList.remove('active')
      })
    })
  }

  // Effet de défilement sur la navbar
  window.addEventListener('scroll', () => {
    const navbar = document.querySelector('.navbar')
    if (window.scrollY > 50) {
      navbar.style.background = 'rgba(255, 255, 255, 0.98)'
      navbar.style.boxShadow = '0 2px 20px rgba(0,0,0,0.1)'
    } else {
      navbar.style.background = 'rgba(255, 255, 255, 0.95)'
      navbar.style.boxShadow = 'none'
    }
  })
}

// Initialiser les animations
function initialiserAnimations() {
  // Animation des cartes de témoignages
  const observateur = new IntersectionObserver((entrees) => {
    entrees.forEach(entree => {
      if (entree.isIntersecting) {
        entree.target.style.opacity = '1'
        entree.target.style.transform = 'translateY(0)'
      }
    })
  })

  document.querySelectorAll('.testimonial-card').forEach(carte => {
    carte.style.opacity = '0'
    carte.style.transform = 'translateY(30px)'
    carte.style.transition = 'all 0.6s ease'
    observateur.observe(carte)
  })

  // Animation des features preview
  document.querySelectorAll('.feature-preview').forEach((feature, index) => {
    feature.style.opacity = '0'
    feature.style.transform = 'translateX(-30px)'
    feature.style.transition = 'all 0.6s ease'
    
    setTimeout(() => {
      feature.style.opacity = '1'
      feature.style.transform = 'translateX(0)'
    }, index * 200)
  })
}

// Vérifier si un utilisateur est connecté
function verifierUtilisateurConnecte() {
  const utilisateur = localStorage.getItem('koyako_utilisateur')
  if (utilisateur) {
    const donneesUtilisateur = JSON.parse(utilisateur)
    
    // Modifier le bouton de connexion
    const boutonConnexion = document.querySelector('.cta-button')
    if (boutonConnexion) {
      boutonConnexion.textContent = 'Mon Tableau de Bord'
      boutonConnexion.href = 'tableau-bord.html'
    }

    // Modifier le CTA principal
    const ctaPrincipal = document.querySelector('.cta-content .btn-primary')
    if (ctaPrincipal) {
      ctaPrincipal.textContent = 'Accéder à mon espace'
      ctaPrincipal.href = 'tableau-bord.html'
    }

    console.log(`Utilisateur connecté: ${donneesUtilisateur.nom || donneesUtilisateur.email}`)
  }
}

// Gestion du redimensionnement
window.addEventListener('resize', () => {
  const hamburger = document.querySelector('.hamburger')
  const navMenu = document.querySelector('.nav-menu')
  
  if (window.innerWidth > 768) {
    hamburger?.classList.remove('active')
    navMenu?.classList.remove('active')
  }
})

// Animation de compteur pour les statistiques (si ajoutées plus tard)
function animerCompteur(element, valeurCible, duree = 2000) {
  let valeurActuelle = 0
  const increment = valeurCible / (duree / 16)

  const timer = setInterval(() => {
    valeurActuelle += increment
    element.textContent = Math.floor(valeurActuelle)

    if (valeurActuelle >= valeurCible) {
      element.textContent = valeurCible
      clearInterval(timer)
    }
  }, 16)
}

console.log('🔷 Script d\'accueil Koyako chargé!')
