// === SCRIPT PRINCIPAL POUR LA PAGE D'ACCUEIL ===

// Fonction pour faire défiler vers une section
function scrollToSection(sectionId) {
  const element = document.getElementById(sectionId)
  if (element) {
    element.scrollIntoView({
      behavior: "smooth",
      block: "start",
    })
  }
}

// Menu mobile
const hamburger = document.querySelector(".hamburger")
const navMenu = document.querySelector(".nav-menu")

if (hamburger && navMenu) {
  hamburger.addEventListener("click", () => {
    hamburger.classList.toggle("active")
    navMenu.classList.toggle("active")
  })

  // Fermer le menu mobile lors du clic sur un lien
  document.querySelectorAll(".nav-menu a").forEach((lien) =>
    lien.addEventListener("click", () => {
      hamburger.classList.remove("active")
      navMenu.classList.remove("active")
    }),
  )
}

// Défilement fluide pour les liens d'ancrage
document.querySelectorAll('a[href^="#"]').forEach((ancre) => {
  ancre.addEventListener("click", function (e) {
    e.preventDefault()
    const cible = document.querySelector(this.getAttribute("href"))
    if (cible) {
      cible.scrollIntoView({
        behavior: "smooth",
        block: "start",
      })
    }
  })
})

// Changement de style de la navbar au défilement
window.addEventListener("scroll", () => {
  const navbar = document.querySelector(".navbar")
  if (window.scrollY > 50) {
    navbar.style.background = "rgba(255, 255, 255, 0.98)"
    navbar.style.boxShadow = "0 2px 20px rgba(0,0,0,0.1)"
  } else {
    navbar.style.background = "rgba(255, 255, 255, 0.95)"
    navbar.style.boxShadow = "none"
  }
})

// Animation simple au défilement (AOS)
function animerAuDefilement() {
  const elements = document.querySelectorAll("[data-aos]")

  elements.forEach((element) => {
    const elementTop = element.getBoundingClientRect().top
    const elementVisible = 150

    if (elementTop < window.innerHeight - elementVisible) {
      element.classList.add("aos-animate")
    }
  })
}

window.addEventListener("scroll", animerAuDefilement)
window.addEventListener("load", animerAuDefilement)

// Vérifier si l'utilisateur est déjà connecté
function verifierAuthentification() {
  const utilisateur = localStorage.getItem("koyako_utilisateur")
  if (utilisateur) {
    const donneesUtilisateur = JSON.parse(utilisateur)
    if (donneesUtilisateur.type === "admin") {
      // Rediriger vers le dashboard admin
      console.log("Utilisateur admin détecté, redirection possible vers dashboard.html")
    } else {
      // Rediriger vers l'espace membre
      console.log("Utilisateur membre détecté")
    }
  }
}

// Appeler la vérification au chargement de la page
document.addEventListener("DOMContentLoaded", verifierAuthentification)

console.log("🔷 Script Koyako chargé avec succès!")
